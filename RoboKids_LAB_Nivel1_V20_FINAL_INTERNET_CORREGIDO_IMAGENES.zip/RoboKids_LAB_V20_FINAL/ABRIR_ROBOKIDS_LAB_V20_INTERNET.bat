@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RoboKids LAB V20 - INTERNET
color 1F
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\iniciar_internet_v20.ps1"
exit /b %errorlevel%
