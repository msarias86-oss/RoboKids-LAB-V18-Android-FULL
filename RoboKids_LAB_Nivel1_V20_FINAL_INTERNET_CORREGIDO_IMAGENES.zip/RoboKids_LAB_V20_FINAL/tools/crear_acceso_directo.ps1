$ErrorActionPreference = 'Stop'

# No recibe la ruta por argumentos: se calcula desde la propia ubicación del script.
# Esto evita el error de Windows cuando la ruta termina en "\\" o contiene espacios.
$Root = Split-Path -Parent $PSScriptRoot
$desktop = [Environment]::GetFolderPath('Desktop')
if ([string]::IsNullOrWhiteSpace($desktop)) {
    throw 'No se pudo localizar el Escritorio de Windows.'
}

$shortcutPath = Join-Path $desktop 'RoboKids LAB - Nivel 1.lnk'
$launcher = Join-Path $Root 'ABRIR_ROBOKIDS_LAB_V20.bat'
$icon = Join-Path $Root 'public\icons\robokids.ico'

if (-not (Test-Path -LiteralPath $launcher)) {
    throw "No se encontró el iniciador: $launcher"
}

$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($shortcutPath)
$sc.TargetPath = $env:ComSpec
$sc.Arguments = '/d /c call "' + $launcher + '"'
$sc.WorkingDirectory = $Root
if (Test-Path -LiteralPath $icon) {
    $sc.IconLocation = $icon + ',0'
}
$sc.Description = 'RoboKids LAB Nivel 1 - abrir servidor y panel del profesor'
$sc.WindowStyle = 1
$sc.Save()

Write-Host "Acceso directo creado correctamente: $shortcutPath"
exit 0
