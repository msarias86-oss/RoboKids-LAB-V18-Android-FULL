﻿param()
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Data = Join-Path $Root 'data'
$Cloudflared = Join-Path $Root 'tools\cloudflared.exe'
$ErrLog = Join-Path $Data 'cloudflared-error.log'
$OutLog = Join-Path $Data 'cloudflared-output.log'
$ServerErr = Join-Path $Data 'robokids-server-error.log'
$ServerOut = Join-Path $Data 'robokids-server-output.log'
$PublicFile = Join-Path $Data 'PUBLIC_URL.txt'
$PortFile = Join-Path $Data 'PORT.txt'
New-Item -ItemType Directory -Force -Path $Data | Out-Null
Remove-Item $PublicFile,$ErrLog,$OutLog,$ServerErr,$ServerOut -Force -ErrorAction SilentlyContinue

Write-Host '======================================================' -ForegroundColor Cyan
Write-Host ' ROBOKIDS LAB V20 - INTERNET + DATOS MOVILES' -ForegroundColor Cyan
Write-Host '======================================================' -ForegroundColor Cyan
Write-Host ''

$nodeCmd = Get-Command node.exe -ErrorAction SilentlyContinue
if (-not $nodeCmd) {
  Write-Host '[ERROR] Node.js no esta instalado o no esta en PATH.' -ForegroundColor Red
  Write-Host 'Instala Node.js LTS desde https://nodejs.org y vuelve a ejecutar RoboKids.' -ForegroundColor Yellow
  Read-Host 'Presiona ENTER para salir'; exit 1
}
$NodeExe = $nodeCmd.Source

$required = @('server.js','missions.js','public\index.html','vendor\QRCode\index.js')
foreach($rel in $required){
  $fp=Join-Path $Root $rel
  if(-not (Test-Path $fp)){
    Write-Host "[ERROR] Falta archivo requerido: $rel" -ForegroundColor Red
    Write-Host 'Descomprime TODO el ZIP antes de ejecutar.' -ForegroundColor Yellow
    Read-Host 'Presiona ENTER para salir'; exit 1
  }
}

Write-Host '[1/4] Verificando servidor RoboKids...' -ForegroundColor Yellow
$check = & $NodeExe '--check' (Join-Path $Root 'server.js') 2>&1
if($LASTEXITCODE -ne 0){
  Write-Host '[ERROR] server.js no supera la verificacion de Node.js:' -ForegroundColor Red
  $check | ForEach-Object { Write-Host $_ }
  Read-Host 'Presiona ENTER para salir'; exit 1
}

# Quitar solamente el puerto guardado de una ejecucion anterior. El servidor lo vuelve a crear al arrancar.
Remove-Item $PortFile -Force -ErrorAction SilentlyContinue

# Iniciar Node desde el directorio de RoboKids. Usar solamente "server.js" evita fallos cuando la ruta de Windows contiene espacios.
$env:NO_BROWSER='1'
try {
  $Server = Start-Process -FilePath $NodeExe -ArgumentList @('server.js') -WorkingDirectory $Root -PassThru -WindowStyle Hidden -RedirectStandardError $ServerErr -RedirectStandardOutput $ServerOut
} catch {
  Write-Host '[ERROR] Windows no pudo ejecutar Node.js.' -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Read-Host 'Presiona ENTER para salir'; exit 1
}

$port = $null
for($i=0;$i -lt 60;$i++){
  Start-Sleep -Milliseconds 500
  if(Test-Path $PortFile){
    $p=(Get-Content $PortFile -Raw).Trim()
    if($p -match '^\d+$'){
      try {
        $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 "http://127.0.0.1:$p/health"
        if($r.StatusCode -eq 200){$port=$p;break}
      } catch {}
    }
  }
  if($Server.HasExited){break}
}

if(-not $port){
  Write-Host ''
  Write-Host '[ERROR] No se pudo iniciar el servidor RoboKids.' -ForegroundColor Red
  if($Server.HasExited){ Write-Host "Node.js finalizo con codigo: $($Server.ExitCode)" -ForegroundColor Yellow }
  if(Test-Path $ServerErr){
    $e=(Get-Content $ServerErr -Raw -ErrorAction SilentlyContinue).Trim()
    if($e){ Write-Host ''; Write-Host 'DETALLE DEL ERROR:' -ForegroundColor Yellow; Write-Host $e -ForegroundColor Red }
  }
  if(Test-Path $ServerOut){
    $o=(Get-Content $ServerOut -Raw -ErrorAction SilentlyContinue).Trim()
    if($o){ Write-Host ''; Write-Host 'SALIDA DEL SERVIDOR:' -ForegroundColor Yellow; Write-Host $o }
  }
  Write-Host ''
  Write-Host "Los registros quedaron en: $Data" -ForegroundColor Cyan
  Read-Host 'Presiona ENTER para salir'; exit 1
}
Write-Host "[OK] Servidor RoboKids activo en puerto $port." -ForegroundColor Green

if(-not (Test-Path $Cloudflared)){
  Write-Host '[2/4] Descargando Cloudflare Tunnel (solo la primera vez)...' -ForegroundColor Yellow
  try{
    Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile $Cloudflared
  } catch {
    Write-Host '[ERROR] No se pudo descargar cloudflared.' -ForegroundColor Red
    Write-Host 'Comprueba que la PC tenga Internet y que antivirus/firewall no bloquee GitHub.' -ForegroundColor Yellow
    Write-Host 'La app local se abrira igualmente.' -ForegroundColor Yellow
    Start-Process "http://127.0.0.1:$port/?role=teacher"
    Read-Host 'Presiona ENTER para cerrar'
    Stop-Process -Id $Server.Id -Force -ErrorAction SilentlyContinue
    exit 1
  }
} else {
  Write-Host '[2/4] Cloudflare Tunnel disponible.' -ForegroundColor Green
}

Write-Host '[3/4] Creando acceso HTTPS publico...' -ForegroundColor Yellow
try{
  $Tunnel = Start-Process -FilePath $Cloudflared -ArgumentList @('tunnel','--no-autoupdate','--url',"http://127.0.0.1:$port") -WorkingDirectory $Root -PassThru -WindowStyle Hidden -RedirectStandardError $ErrLog -RedirectStandardOutput $OutLog
}catch{
  Write-Host '[ERROR] No se pudo iniciar Cloudflare Tunnel.' -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Start-Process "http://127.0.0.1:$port/?role=teacher"
  Read-Host 'Presiona ENTER para cerrar'
  Stop-Process -Id $Server.Id -Force -ErrorAction SilentlyContinue
  exit 1
}

$url=$null
for($i=0;$i -lt 120;$i++){
  Start-Sleep -Milliseconds 500
  $txt=''
  if(Test-Path $ErrLog){$txt += (Get-Content $ErrLog -Raw -ErrorAction SilentlyContinue)}
  if(Test-Path $OutLog){$txt += "`n"+(Get-Content $OutLog -Raw -ErrorAction SilentlyContinue)}
  $m=[regex]::Match($txt,'https://[a-zA-Z0-9-]+\.trycloudflare\.com')
  if($m.Success){$url=$m.Value;break}
  if($Tunnel.HasExited){break}
}
if(-not $url){
  Write-Host '[ERROR] No se pudo obtener la URL publica de Cloudflare.' -ForegroundColor Red
  if(Test-Path $ErrLog){
    $e=(Get-Content $ErrLog -Raw -ErrorAction SilentlyContinue).Trim()
    if($e){ Write-Host ''; Write-Host 'DETALLE CLOUDFLARE:' -ForegroundColor Yellow; Write-Host $e -ForegroundColor Red }
  }
  Write-Host 'La app local sigue disponible, pero no se habilitaron datos moviles.' -ForegroundColor Yellow
  Start-Process "http://127.0.0.1:$port/?role=teacher"
  Read-Host 'Presiona ENTER para cerrar'
  Stop-Process -Id $Server.Id -Force -ErrorAction SilentlyContinue
  exit 1
}

# Confirmar que la URL publica responde antes de publicarla al QR.
Write-Host '[4/4] Verificando acceso desde Internet...' -ForegroundColor Yellow
$internetOk=$false
for($i=0;$i -lt 30;$i++){
  try{
    $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 5 "$url/api/ping"
    if($r.StatusCode -eq 200){$internetOk=$true;break}
  } catch {}
  Start-Sleep -Seconds 1
}
if(-not $internetOk){
  Write-Host '[AVISO] La URL fue creada pero todavia no respondio a la prueba HTTPS.' -ForegroundColor Yellow
  Write-Host 'Puede tardar unos segundos mas; se continuara igualmente.' -ForegroundColor Yellow
}

Set-Content -Path $PublicFile -Value $url -Encoding ASCII
Start-Sleep -Milliseconds 500
Write-Host ''
Write-Host '======================================================' -ForegroundColor Green
Write-Host ' ROBOKIDS LAB V20 - LISTO' -ForegroundColor Green
Write-Host '======================================================' -ForegroundColor Green
Write-Host "URL PUBLICA: $url" -ForegroundColor Green
Write-Host 'El QR del Profesor usara esta URL automaticamente.' -ForegroundColor Green
Write-Host 'Los alumnos pueden entrar por Wi-Fi o DATOS MOVILES.' -ForegroundColor Green
Write-Host ''
Write-Host 'IMPORTANTE: mantener esta ventana abierta durante toda la clase.' -ForegroundColor Yellow
Start-Process "http://127.0.0.1:$port/?role=teacher"
try { Wait-Process -Id $Server.Id } finally {
  if($Tunnel){ Stop-Process -Id $Tunnel.Id -Force -ErrorAction SilentlyContinue }
  Remove-Item $PublicFile -Force -ErrorAction SilentlyContinue
}
