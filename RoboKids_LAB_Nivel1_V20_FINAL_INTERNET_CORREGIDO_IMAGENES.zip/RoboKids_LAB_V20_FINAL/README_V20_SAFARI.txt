ROBOKIDS LAB NIVEL 1 - V20 REALTIME SAFARI
===========================================

CAMBIO PRINCIPAL
- Esta version NO usa npm install.
- NO usa Express.
- NO usa Socket.IO.
- Solo necesita Node.js.
- El servidor usa modulos nativos de Node.
- La sincronizacion se realiza por polling cada 1 segundo.
- El QR se genera localmente en SVG; no usa Internet.
- El QR apunta a una ruta corta: http://IP:3000/join/CODIGO
- /join/CODIGO redirige a la pantalla Participante con la sala precargada.


RESPONDER COMO ALUMNO - NUEVO EN V20
- Al crear la sala, la Mision 1 queda automaticamente en fase RESPONDER.
- Al cambiar de mision, la nueva pregunta tambien queda abierta automaticamente.
- En iPhone/iPad el alumno toca una opcion grande para enviar su respuesta.
- La pantalla muestra RESPUESTA ENVIADA inmediatamente.
- Puede cambiar la opcion mientras el profesor no haya pulsado Revelar y puntuar.
- Cada respuesta queda vinculada al participante y a su equipo.
- El profesor ve cantidad de votos y calcula el puntaje por equipo al revelar.

WINDOWS
1. Descomprima el ZIP completamente.
2. Ejecute INICIAR_ROBOKIDS_V20_WINDOWS.bat.
3. Espere a que se abra el panel Profesor.
4. Cree una sala.
5. Elija la direccion Wi-Fi correcta en "Direccion utilizada por el QR".
6. Escanee el QR con la Camara del iPhone y abra la notificacion en Safari.

PRUEBA SAFARI
Antes de culpar al QR, escriba manualmente en Safari:
http://IP_DE_LA_PC:3000/api/ping

Debe aparecer un JSON con "ok":true.

SI /api/ping NO ABRE
- PC y iPhone deben estar en la misma Wi-Fi.
- No usar una Wi-Fi Guest/Invitados con aislamiento de clientes.
- Ejecutar HABILITAR_FIREWALL_WINDOWS.bat como Administrador.
- Desactivar temporalmente VPN si interfiere.
- En el panel Profesor, elegir la IP Wi-Fi real (normalmente 192.168.x.x o 10.x.x.x).

SAFARI
La app usa JavaScript compatible con Safari moderno y no depende de WebSockets,
BroadcastChannel, service workers ni APIs exclusivas de Chromium.

IMPORTANTE
El acceso desde Safari por HTTP local funciona solo si el iPhone puede alcanzar la IP local de la PC.
El QR no puede superar un bloqueo de firewall o aislamiento Wi-Fi.

PUERTO OCUPADO
Si 3000 esta ocupado, el servidor prueba automaticamente 3001, 3002... hasta 3010.
El QR usa automaticamente el puerto real.
