'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const child_process = require('child_process');
const { URL } = require('url');
const missions = require('./missions');
const QRCode = require('./vendor/QRCode');
const QRErrorCorrectLevel = require('./vendor/QRCode/QRErrorCorrectLevel');

let ACTIVE_PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_FILE = path.join(ROOT, 'data', 'rooms.json');
const PUBLIC_URL_FILE = path.join(ROOT, 'data', 'PUBLIC_URL.txt');
function normalizeBase(v){
  v=String(v||'').trim().replace(/\/+$/,'');
  return /^https?:\/\//i.test(v)?v:'';
}
function getPublicBase(){
  let v=normalizeBase(process.env.PUBLIC_URL||'');
  if(v) return v;
  try{ if(fs.existsSync(PUBLIC_URL_FILE)) v=normalizeBase(fs.readFileSync(PUBLIC_URL_FILE,'utf8')); }catch(e){}
  return v||'';
}
function requestProto(req){
  const xf=String(req.headers['x-forwarded-proto']||'').split(',')[0].trim();
  return xf||((req.socket&&req.socket.encrypted)?'https':'http');
}
const TEAMS = [
  {id:'azul', name:'Equipo Azul', emoji:'🔵'},
  {id:'verde', name:'Equipo Verde', emoji:'🟢'},
  {id:'naranja', name:'Equipo Naranja', emoji:'🟠'},
  {id:'violeta', name:'Equipo Violeta', emoji:'🟣'}
];
const PHASES = ['briefing','question','programming','testing','results'];
const VERSION = 'V20-INTERNET-MULTIACCESS';
const rooms = new Map();

function now(){ return Date.now(); }
function makeCode(){
  const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out=''; for(let i=0;i<6;i++) out += chars[Math.floor(Math.random()*chars.length)];
  return out;
}
function token(){ return crypto.randomBytes(18).toString('hex'); }
function roomOf(code){ return rooms.get(String(code||'').trim().toUpperCase()); }
function getMission(room){ return missions.find(m=>m.id===Number(room.missionId)) || missions[0]; }
function timerRemaining(room){
  if(room.timer.running) return Math.max(0, room.timer.endAt-now());
  return Math.max(0, room.timer.remainingMs||0);
}
function ensureTimer(room){
  const r=timerRemaining(room);
  if(room.timer.running && r<=0){ room.timer.running=false; room.timer.remainingMs=0; room.timer.endAt=0; }
}
function recomputeScores(room){
  const scores={azul:0,verde:0,naranja:0,violeta:0};
  for(const award of Object.values(room.digitalAwards||{})){
    for(const t of TEAMS) scores[t.id]+=Number((award||{})[t.id]||0);
  }
  for(const award of Object.values(room.physicalAwards||{})){
    for(const t of TEAMS) scores[t.id]+=Number((award||{})[t.id]||0);
  }
  room.scores=scores;
}
function rank(room){
  return TEAMS.map(t=>({...t,score:Number(room.scores[t.id]||0)})).sort((a,b)=>b.score-a.score || TEAMS.findIndex(x=>x.id===a.id)-TEAMS.findIndex(x=>x.id===b.id));
}
function saveRooms(){
  try{
    fs.mkdirSync(path.dirname(DATA_FILE),{recursive:true});
    const payload={rooms:[...rooms.values()]};
    fs.writeFileSync(DATA_FILE, JSON.stringify(payload,null,2));
  }catch(e){ console.error('No se pudo guardar rooms.json:',e.message); }
}
let saveTimer=null;
function saveSoon(){ clearTimeout(saveTimer); saveTimer=setTimeout(saveRooms,100); }
function loadRooms(){
  try{
    if(!fs.existsSync(DATA_FILE)) return;
    const data=JSON.parse(fs.readFileSync(DATA_FILE,'utf8'));
    for(const room of data.rooms||[]){
      room.participants=room.participants||{};
      room.stations=room.stations||{};
      room.responses=room.responses||{};
      room.digitalAwards=room.digitalAwards||{};
      room.physicalAwards=room.physicalAwards||{};
      room.evidenceOpen=room.evidenceOpen||{};
      room.timer=room.timer||{running:false,durationMs:60000,remainingMs:60000,endAt:0};
      ensureTimer(room); recomputeScores(room); rooms.set(room.code,room);
    }
    console.log('Salas recuperadas:', rooms.size);
  }catch(e){ console.error('No se pudo cargar rooms.json:',e.message); }
}
loadRooms();

function newRoom(){
  let c; do{c=makeCode();}while(rooms.has(c));
  const room={
    code:c,hostKey:token(),createdAt:now(),updatedAt:now(),missionId:1,phase:'question',turnTeam:'azul',revealed:false,
    responses:{},digitalAwards:{},physicalAwards:{},scores:{azul:0,verde:0,naranja:0,violeta:0},
    participants:{},stations:{},timer:{running:false,durationMs:60000,remainingMs:60000,endAt:0},evidenceOpen:{},notes:''
  };
  rooms.set(c,room); saveSoon(); return room;
}
function connected(ts){ return now()-Number(ts||0) < 15000; }
function teamSummary(room){
  return TEAMS.map(t=>({
    ...t, score:Number(room.scores[t.id]||0),
    connected:Object.values(room.participants).filter(p=>p.teamId===t.id&&connected(p.lastSeen)).length,
    total:Object.values(room.participants).filter(p=>p.teamId===t.id).length,
    answered:Object.values((((room.responses||{})[room.missionId]||{})[t.id]||{})).length,
    station:room.stations[t.id]?{status:room.stations[t.id].status||'esperando',observation:room.stations[t.id].observation||'',connected:connected(room.stations[t.id].lastSeen)}:null
  }));
}
function evidenceCatalog(m){
  return [
    {id:'pista',title:'💡 Pista del profesor',text:m.teacher},
    {id:'observar',title:'👀 Qué observar',text:m.program.observe},
    {id:'error',title:'🧩 Error típico',text:m.program.error},
    {id:'pregunta',title:'❓ Pregunta guía',text:m.program.question}
  ];
}
function openedEvidence(room){
  const open=((room.evidenceOpen||{})[room.missionId]||[]);
  return evidenceCatalog(getMission(room)).filter(e=>open.includes(e.id));
}
function questionPublic(m,room,includeResolution){
  const q={title:m.question.title,subtitle:m.question.subtitle,options:m.question.options};
  if(includeResolution || room.revealed || room.phase==='results'){
    q.correct=m.question.correct; q.explanation=m.question.explanation;
  }
  return q;
}
function aggregateResponses(room){
  const m=getMission(room); const r=(room.responses||{})[room.missionId]||{}; const out={};
  for(const t of TEAMS){
    const vals=Object.values(r[t.id]||{}).map(x=>x.value);
    const counts={}; vals.forEach(v=>counts[v]=(counts[v]||0)+1);
    const sorted=Object.entries(counts).sort((a,b)=>b[1]-a[1]);
    const tie=sorted.length>1&&sorted[0][1]===sorted[1][1];
    const majority=sorted.length&&!tie?sorted[0][0]:null;
    out[t.id]={counts,total:vals.length,majority,correct:room.revealed&&majority?majority===m.question.correct:null};
  }
  return out;
}
function scoreQuestion(room){
  const agg=aggregateResponses(room); const m=getMission(room); const award={};
  TEAMS.forEach(t=>award[t.id]=(agg[t.id].majority===m.question.correct)?100:0);
  room.digitalAwards[room.missionId]=award; recomputeScores(room);
}
function commonState(room){
  ensureTimer(room); const m=getMission(room);
  return {
    roomCode:room.code,missionId:room.missionId,missionCount:missions.length,phase:room.phase,revealed:room.revealed,
    mission:{id:m.id,title:m.title,stage:m.stage,subtitle:m.subtitle},
    timer:{running:room.timer.running,remainingMs:timerRemaining(room),durationMs:room.timer.durationMs},
    turnTeam:room.turnTeam,teams:teamSummary(room),ranking:rank(room),participantCount:Object.keys(room.participants).length,phases:PHASES
  };
}
function stateFor(room,role,clientId,teamId,hostKey){
  const m=getMission(room), common=commonState(room);
  if(role==='teacher'){
    if(hostKey!==room.hostKey) throw new Error('Clave de profesor inválida');
    return {...common,question:questionPublic(m,room,true),teacher:m.teacher,program:m.program,responses:aggregateResponses(room),
      participants:Object.values(room.participants).map(p=>({id:p.clientId,name:p.name,teamId:p.teamId,connected:connected(p.lastSeen),lastSeen:p.lastSeen})),
      evidenceCatalog:evidenceCatalog(m).map(e=>({...e,open:((room.evidenceOpen||{})[room.missionId]||[]).includes(e.id)})),notes:room.notes||''};
  }
  if(role==='player'){
    const p=room.participants[clientId]; if(p) p.lastSeen=now();
    const tid=(p&&p.teamId)||teamId;
    const mine=(((((room.responses||{})[room.missionId]||{})[tid]||{})[clientId])||{}).value||null;
    return {...common,question:questionPublic(m,room,false),me:p?{name:p.name,teamId:p.teamId,connected:true}:null,myAnswer:mine,
      canAnswer:room.phase==='question'&&!room.revealed,teamResults:room.revealed?aggregateResponses(room):undefined,evidence:openedEvidence(room)};
  }
  if(role==='station'){
    if(room.stations[teamId]) room.stations[teamId].lastSeen=now();
    const allowed=['programming','testing','results'].includes(room.phase);
    return {...common,program:allowed?m.program:null,teacherPrompt:allowed?m.teacher:null,station:room.stations[teamId]||{teamId,status:'esperando',observation:''},evidence:openedEvidence(room)};
  }
  if(role==='screen') return {...common,question:questionPublic(m,room,false),teamResults:room.revealed?aggregateResponses(room):undefined,evidence:openedEvidence(room)};
  return common;
}

function privateIPv4(addr){
  return /^10\./.test(addr)||/^192\.168\./.test(addr)||/^172\.(1[6-9]|2\d|3[01])\./.test(addr);
}
function networkList(){
  const bad=/virtual|vmware|virtualbox|hyper-v|vethernet|wsl|docker|tailscale|zerotier|wireguard|vpn|loopback|bluetooth/i;
  const wifi=/wi-?fi|wireless|wlan/i;
  const ethernet=/ethernet|en\d|eth\d/i;
  const out=[];
  for(const [name,list] of Object.entries(os.networkInterfaces())){
    for(const n of list||[]){
      if(n.family!=='IPv4'||n.internal) continue;
      if(!n.address||/^169\.254\./.test(n.address)||/^0\./.test(n.address)||/^127\./.test(n.address)) continue;
      let score=0;
      if(privateIPv4(n.address)) score+=120;
      if(wifi.test(name)) score+=70;
      else if(ethernet.test(name)) score+=35;
      if(bad.test(name)) score-=250;
      out.push({name,address:n.address,url:`http://${n.address}:${ACTIVE_PORT}`,score});
    }
  }
  out.sort((a,b)=>b.score-a.score||a.name.localeCompare(b.name));
  return out;
}
function parseCookies(req){
  const out={};
  String(req.headers.cookie||'').split(';').forEach(part=>{const i=part.indexOf('=');if(i<0)return;const k=part.slice(0,i).trim();const v=part.slice(i+1).trim();if(k)out[k]=decodeURIComponent(v);});
  return out;
}
function studentToken(req,u){
  const hdr=String(req.headers['x-robokids-student']||'').trim().toUpperCase();
  const q=String((u&&u.searchParams&&u.searchParams.get('rk'))||'').trim().toUpperCase();
  const room=String((u&&u.searchParams&&u.searchParams.get('room'))||'').trim().toUpperCase();
  const access=String((u&&u.searchParams&&u.searchParams.get('access'))||'').toLowerCase();
  const ck=String(parseCookies(req).rk_student||'').trim().toUpperCase();
  if(hdr)return hdr;if(q)return q;if(access==='student'&&room)return room;return ck;
}
function studentRestricted(req,u){return !!studentToken(req,u);}
function allowedStudentRole(role){return role==='player'||role==='station';}

function sendJson(res,status,obj){
  const body=Buffer.from(JSON.stringify(obj));
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':body.length,'Cache-Control':'no-store'}); res.end(body);
}
function sendText(res,status,text,type='text/plain; charset=utf-8'){
  const body=Buffer.from(text); res.writeHead(status,{'Content-Type':type,'Content-Length':body.length,'Cache-Control':'no-store'}); res.end(body);
}
function readJson(req){
  return new Promise((resolve,reject)=>{
    let body=''; req.on('data',d=>{body+=d;if(body.length>200000){reject(new Error('Body muy grande'));req.destroy();}});
    req.on('end',()=>{try{resolve(body?JSON.parse(body):{});}catch(e){reject(e);}}); req.on('error',reject);
  });
}
function qrSvg(text){
  const qr=new QRCode(-1,QRErrorCorrectLevel.M); qr.addData(text); qr.make();
  const count=qr.getModuleCount(); const margin=4; const scale=8; const size=(count+margin*2)*scale;
  let pathData='';
  for(let r=0;r<count;r++) for(let c=0;c<count;c++) if(qr.isDark(r,c)) pathData+=`M${(c+margin)*scale},${(r+margin)*scale}h${scale}v${scale}h-${scale}z`;
  return `<?xml version="1.0" encoding="UTF-8"?><svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><rect width="100%" height="100%" fill="white"/><path d="${pathData}" fill="black"/></svg>`;
}
function serveFile(res,file,extraHeaders){
  fs.readFile(file,(err,data)=>{
    if(err) return sendText(res,404,'No encontrado');
    const ext=path.extname(file).toLowerCase();
    const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.webmanifest':'application/manifest+json; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8'};
    res.writeHead(200,Object.assign({'Content-Type':types[ext]||'application/octet-stream','Content-Length':data.length,'Cache-Control':'no-store, no-cache, must-revalidate','Pragma':'no-cache'},extraHeaders||{}));res.end(data);
  });
}

async function handleApi(req,res,u){
  if(req.method==='GET'&&u.pathname==='/health') return sendJson(res,200,{ok:true,version:VERSION,rooms:rooms.size,time:new Date().toISOString()});
  if(req.method==='GET'&&u.pathname==='/api/ping') return sendJson(res,200,{ok:true,host:req.headers.host||'',version:VERSION,publicUrl:getPublicBase(),internetReady:!!getPublicBase(),time:new Date().toISOString()});
  if(req.method==='GET'&&u.pathname==='/api/network'){
    const interfaces=networkList();
    const publicUrl=getPublicBase();
    return sendJson(res,200,{ok:true,port:ACTIVE_PORT,interfaces,preferred:interfaces[0]||null,local:`http://127.0.0.1:${ACTIVE_PORT}`,publicUrl,internetReady:!!publicUrl});
  }
  if(req.method==='GET'&&u.pathname==='/api/access-test'){
    return sendJson(res,200,{ok:true,version:VERSION,host:req.headers.host||'',publicUrl:getPublicBase(),internetReady:!!getPublicBase(),userAgent:req.headers['user-agent']||'',student:studentRestricted(req,u),room:studentToken(req,u)||'',time:new Date().toISOString()});
  }
  if(req.method==='GET'&&u.pathname==='/api/qr'){
    const text=String(u.searchParams.get('text')||'').slice(0,500); if(!text)return sendText(res,400,'Falta text');
    return sendText(res,200,qrSvg(text),'image/svg+xml; charset=utf-8');
  }
  if(req.method==='GET'&&u.pathname==='/api/state'){
    const room=roomOf(u.searchParams.get('room')); if(!room)return sendJson(res,404,{ok:false,error:'Sala inexistente'});
    try{
      const role=u.searchParams.get('role')||''; const clientId=u.searchParams.get('clientId')||''; const teamId=u.searchParams.get('teamId')||''; const hostKey=u.searchParams.get('hostKey')||'';
      if(studentRestricted(req,u)&&!allowedStudentRole(role)) return sendJson(res,403,{ok:false,error:'Acceso QR/link restringido a Participante y Estación ACECode'});
      const state=stateFor(room,role,clientId,teamId,hostKey); saveSoon(); return sendJson(res,200,{ok:true,state});
    }catch(e){return sendJson(res,403,{ok:false,error:e.message});}
  }
  if(req.method==='POST'&&u.pathname==='/api/create-room'){
    if(studentRestricted(req,u)) return sendJson(res,403,{ok:false,error:'Acceso alumno: no se puede crear una sala'});
    const room=newRoom(); return sendJson(res,200,{ok:true,roomCode:room.code,hostKey:room.hostKey,state:stateFor(room,'teacher','','',room.hostKey)});
  }
  if(req.method==='POST'&&u.pathname==='/api/join-room'){
    const p=await readJson(req); const room=roomOf(p.roomCode); if(!room)return sendJson(res,404,{ok:false,error:'Sala inexistente'});
    const role=String(p.role||''); const clientId=String(p.clientId||token());
    if(studentRestricted(req,u)&&!allowedStudentRole(role)) return sendJson(res,403,{ok:false,error:'Acceso QR/link restringido a Participante y Estación ACECode'});
    if(role==='teacher'){
      if(p.hostKey!==room.hostKey) return sendJson(res,403,{ok:false,error:'Clave de profesor inválida'});
    } else if(role==='player'){
      let user=room.participants[clientId];
      if(!user){
        let tid=TEAMS.some(t=>t.id===p.teamId)?p.teamId:null;
        if(!tid){
          const counts=Object.fromEntries(TEAMS.map(t=>[t.id,Object.values(room.participants).filter(x=>x.teamId===t.id).length]));
          tid=[...TEAMS].sort((a,b)=>counts[a.id]-counts[b.id])[0].id;
        }
        user={clientId,name:String(p.name||'Participante').trim().slice(0,40)||'Participante',teamId:tid,joinedAt:now(),lastSeen:now()}; room.participants[clientId]=user;
      } else user.lastSeen=now();
    } else if(role==='station'){
      const tid=TEAMS.some(t=>t.id===p.teamId)?p.teamId:'azul';
      room.stations[tid]={...(room.stations[tid]||{}),teamId:tid,status:(room.stations[tid]||{}).status||'esperando',observation:(room.stations[tid]||{}).observation||'',lastSeen:now()};
    } else if(role!=='screen') return sendJson(res,400,{ok:false,error:'Rol inválido'});
    saveSoon();
    try{return sendJson(res,200,{ok:true,state:stateFor(room,role,clientId,p.teamId,p.hostKey)});}catch(e){return sendJson(res,403,{ok:false,error:e.message});}
  }
  if(req.method==='POST'&&u.pathname==='/api/action'){
    const p=await readJson(req); const room=roomOf(p.roomCode); if(!room)return sendJson(res,404,{ok:false,error:'Sala inexistente'});
    const role=String(p.role||''); const type=String(p.type||''); const clientId=String(p.clientId||'');
    if(studentRestricted(req,u)&&!allowedStudentRole(role)) return sendJson(res,403,{ok:false,error:'Acceso QR/link restringido a Participante y Estación ACECode'});
    if(role==='player'){
      if(type!=='answer') return sendJson(res,403,{ok:false,error:'Acción no permitida'});
      if(room.phase!=='question'||room.revealed) return sendJson(res,409,{ok:false,error:'La pregunta no está abierta'});
      const user=room.participants[clientId]; if(!user)return sendJson(res,403,{ok:false,error:'Participante no registrado'});
      const m=getMission(room); if(!m.question.options.some(o=>o[0]===p.value))return sendJson(res,400,{ok:false,error:'Respuesta inválida'});
      room.responses[room.missionId]??={}; room.responses[room.missionId][user.teamId]??={}; room.responses[room.missionId][user.teamId][clientId]={value:p.value,at:now()}; user.lastSeen=now();
      saveSoon(); return sendJson(res,200,{ok:true,state:stateFor(room,'player',clientId,user.teamId,'')});
    }
    if(role==='station'){
      const tid=TEAMS.some(t=>t.id===p.teamId)?p.teamId:null; if(!tid)return sendJson(res,400,{ok:false,error:'Equipo inválido'});
      const st=room.stations[tid]??={teamId:tid,status:'esperando',observation:'',lastSeen:now()};
      if(type==='station-status')st.status=String(p.value||'esperando').slice(0,30);
      else if(type==='station-observation')st.observation=String(p.value||'').slice(0,80);
      else return sendJson(res,403,{ok:false,error:'Acción no permitida'});
      st.lastSeen=now(); saveSoon(); return sendJson(res,200,{ok:true});
    }
    if(role!=='teacher'||p.hostKey!==room.hostKey) return sendJson(res,403,{ok:false,error:'Solo el profesor puede hacer esto'});
    if(type==='set-phase'){
      if(!PHASES.includes(p.phase))return sendJson(res,400,{ok:false,error:'Fase inválida'});
      if(room.phase==='question'&&p.phase!=='question'&&!room.revealed){room.revealed=true;scoreQuestion(room);} room.phase=p.phase;
    } else if(type==='set-mission'){
      room.missionId=Math.max(1,Math.min(missions.length,Number(p.missionId)||1)); room.phase='question'; room.revealed=false; room.timer={running:false,durationMs:60000,remainingMs:60000,endAt:0};
    } else if(type==='reveal'){ if(!room.revealed){room.revealed=true;scoreQuestion(room);} }
    else if(type==='reset-question'){room.responses[room.missionId]={};room.revealed=false;delete room.digitalAwards[room.missionId];recomputeScores(room);}
    else if(type==='set-turn-team'){if(TEAMS.some(t=>t.id===p.teamId))room.turnTeam=p.teamId;}
    else if(type==='toggle-evidence'){
      const valid=evidenceCatalog(getMission(room)).some(e=>e.id===p.evidenceId); if(!valid)return sendJson(res,400,{ok:false,error:'Evidencia inválida'});
      room.evidenceOpen[room.missionId]??=[]; const arr=room.evidenceOpen[room.missionId]; const i=arr.indexOf(p.evidenceId); const open=p.opened===undefined?i<0:!!p.opened;
      if(open&&i<0)arr.push(p.evidenceId); if(!open&&i>=0)arr.splice(i,1);
    } else if(type==='physical-pass'){
      if(!TEAMS.some(t=>t.id===p.teamId))return sendJson(res,400,{ok:false,error:'Equipo inválido'}); room.physicalAwards[room.missionId]??={}; room.physicalAwards[room.missionId][p.teamId]=p.passed?100:0; recomputeScores(room);
    } else if(type==='timer-start'){const rem=timerRemaining(room)||room.timer.durationMs;room.timer.remainingMs=rem;room.timer.endAt=now()+rem;room.timer.running=true;}
    else if(type==='timer-pause'){room.timer.remainingMs=timerRemaining(room);room.timer.running=false;room.timer.endAt=0;}
    else if(type==='timer-reset'){const sec=Math.max(10,Math.min(900,Number(p.seconds)||60));room.timer={running:false,durationMs:sec*1000,remainingMs:sec*1000,endAt:0};}
    else return sendJson(res,400,{ok:false,error:'Acción desconocida'});
    room.updatedAt=now(); saveSoon(); return sendJson(res,200,{ok:true});
  }
  return false;
}

const server=http.createServer(async (req,res)=>{
  try{
    const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);
    if(u.pathname.startsWith('/api/')||u.pathname==='/health'){
      const handled=await handleApi(req,res,u); if(handled!==false)return;
    }
    const jm=u.pathname.match(/^\/join\/([A-Za-z0-9]{4,12})$/);
    if(jm){
      const c=jm[1].toUpperCase();
      const host=req.headers.host||`127.0.0.1:${ACTIVE_PORT}`;
      const base=getPublicBase()||`${requestProto(req)}://${host}`;
      const target=`${base}/?access=student&room=${encodeURIComponent(c)}&rk=${encodeURIComponent(c)}`;
      const body=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=${target}"><title>RoboKids LAB · Acceso</title></head><body style="font-family:Arial;background:#f5f9ff;color:#10224d;display:grid;place-items:center;min-height:100vh;margin:0"><div style="max-width:520px;background:#fff;padding:28px;border-radius:24px;text-align:center"><h1>RoboKids LAB</h1><p>Abriendo acceso de alumno…</p><p><a style="display:inline-block;background:#2379ff;color:#fff;padding:13px 18px;border-radius:14px;text-decoration:none;font-weight:800" href="${target}">Continuar en Chrome / Safari</a></p></div><script>try{localStorage.setItem('rk_v20_student_room',${JSON.stringify(c)});sessionStorage.setItem('rk_v20_student_room',${JSON.stringify(c)});}catch(e){}location.replace(${JSON.stringify(target)});<\/script></body></html>`;
      const b=Buffer.from(body);
      res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Length':b.length,'Cache-Control':'no-store, no-cache, must-revalidate','Pragma':'no-cache','Set-Cookie':`rk_student=${encodeURIComponent(c)}; Path=/; SameSite=Lax; Max-Age=28800`});
      return res.end(b);
    }
    if(u.pathname==='/abrir-profesor'){
      const tok=studentToken(req,u);
      if(tok){res.writeHead(302,{Location:`/?access=student&room=${encodeURIComponent(tok)}&rk=${encodeURIComponent(tok)}`,'Cache-Control':'no-store'});return res.end();}
      res.writeHead(302,{Location:`http://127.0.0.1:${ACTIVE_PORT}/?role=teacher`,'Cache-Control':'no-store'}); return res.end();
    }
    if(u.pathname==='/diagnostico'){
      const nets=networkList();
      const items=nets.map(n=>`<li><b>${n.name}</b>: <a href="${n.url}/api/ping">${n.url}/api/ping</a></li>`).join('');
      const pub=getPublicBase();
      const body=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RoboKids diagnóstico</title><style>body{font-family:Arial,sans-serif;max-width:760px;margin:30px auto;padding:20px;color:#10224d}code{background:#eef4ff;padding:4px 7px;border-radius:6px}li{margin:10px 0}.ok{background:#e8f8ef;padding:14px;border-radius:12px}.warn{background:#fff7dc;padding:14px;border-radius:12px}</style></head><body><h1>RoboKids LAB V20 · Diagnóstico Internet</h1><div class="ok">Servidor activo en puerto <b>${ACTIVE_PORT}</b>.</div>${pub?`<div class="ok">Acceso público HTTPS activo: <a href="${pub}/api/ping">${pub}</a>. Los alumnos pueden usar Wi‑Fi o datos móviles.</div>`:`<div class="warn">Modo Internet todavía no tiene URL pública. Iniciá V20 con el acceso Internet/Cloudflare.</div>`}<p>Direcciones LAN disponibles:</p><ul>${items}</ul></body></html>`;
      return sendText(res,200,body,'text/html; charset=utf-8');
    }
    if(u.pathname==='/instalar'||u.pathname==='/instalar/') return serveFile(res,path.join(PUBLIC_DIR,'instalar.html'));
    if(u.pathname==='/'||u.pathname==='/index.html'){
      const tok=studentToken(req,u);const role=String(u.searchParams.get('role')||'');
      if(tok&&role&&!allowedStudentRole(role)){res.writeHead(302,{Location:`/?access=student&room=${encodeURIComponent(tok)}&rk=${encodeURIComponent(tok)}`,'Cache-Control':'no-store'});return res.end();}
      return serveFile(res,path.join(PUBLIC_DIR,'index.html'),tok?{'Set-Cookie':`rk_student=${encodeURIComponent(tok)}; Path=/; SameSite=Lax; Max-Age=28800`}:null);
    }
    const clean=path.normalize(decodeURIComponent(u.pathname)).replace(/^([.][.][\/\\])+/, '');
    const file=path.join(PUBLIC_DIR,clean); if(file.startsWith(PUBLIC_DIR)&&fs.existsSync(file)&&fs.statSync(file).isFile()) return serveFile(res,file);
    return sendText(res,404,'No encontrado');
  }catch(e){ console.error(e); if(!res.headersSent)sendJson(res,500,{ok:false,error:'Error interno'}); else res.end(); }
});

setInterval(()=>{let changed=false;for(const r of rooms.values()){const before=r.timer.running;ensureTimer(r);if(before&&!r.timer.running)changed=true;}if(changed)saveSoon();},500);

function writeServerInfo(){
  try{
    fs.mkdirSync(path.join(ROOT,'data'),{recursive:true});
    const nets=networkList();
    const preferred=nets[0]||null;
    const info={
      port:ACTIVE_PORT,
      version:VERSION,
      pid:process.pid,
      startedAt:new Date().toISOString(),
      preferredIp:preferred?preferred.address:'',
      lanUrl:preferred?preferred.url:`http://127.0.0.1:${ACTIVE_PORT}`,
      localUrl:`http://127.0.0.1:${ACTIVE_PORT}`,
      publicUrl:getPublicBase(),
      internetReady:!!getPublicBase(),
      interfaces:nets
    };
    fs.writeFileSync(path.join(ROOT,'data','server-info.json'),JSON.stringify(info,null,2));
    fs.writeFileSync(path.join(ROOT,'data','PORT.txt'),String(ACTIVE_PORT));
    fs.writeFileSync(path.join(ROOT,'data','LOCAL_URL.txt'),info.localUrl+'/?role=teacher');
    fs.writeFileSync(path.join(ROOT,'data','LAN_URLS.txt'),nets.map(n=>n.url).join('\r\n'));
  }catch(e){ console.error('No se pudo escribir server-info.json:',e.message); }
}
function openBrowser(url){
  if(process.env.NO_BROWSER==='1') return;
  try{
    if(process.platform==='win32'){
      // Usar el manejador de URL de Windows evita que las comillas se interpreten
      // como parte del nombre del archivo (error observado con cmd /c start).
      const c=child_process.spawn('rundll32.exe',['url.dll,FileProtocolHandler',url],{detached:true,stdio:'ignore',windowsHide:true});
      c.unref();
    }else if(process.platform==='darwin'){
      const c=child_process.spawn('open',[url],{detached:true,stdio:'ignore'}); c.unref();
    }else{
      const c=child_process.spawn('xdg-open',[url],{detached:true,stdio:'ignore'}); c.unref();
    }
  }catch(e){ console.error('No se pudo abrir el navegador automáticamente:',e.message); }
}
function startListening(port){
  ACTIVE_PORT=port;
  const onError=(err)=>{
    server.removeListener('listening',onListen);
    if(err&&err.code==='EADDRINUSE'&&port<3010){console.log(`Puerto ${port} ocupado. Probando ${port+1}...`);setTimeout(()=>startListening(port+1),150);return;}
    console.error('No se pudo iniciar el servidor:',err&&err.message?err.message:err);process.exit(1);
  };
  const onListen=()=>{
    server.removeListener('error',onError);
    writeServerInfo();
    const teacherUrl=`http://127.0.0.1:${ACTIVE_PORT}/?role=teacher`;
    console.log('\n======================================================');
    console.log(' ROBOKIDS LAB V20 - SERVIDOR ACTIVO · INTERNET + LAN');
    console.log('======================================================');
    console.log(`ABRIR PROFESOR EN ESTA PC: ${teacherUrl}`);
    console.log('\nDIRECCIONES POSIBLES PARA CELULARES:');
    const nets=networkList();
    if(!nets.length) console.log('  No se detectaron interfaces LAN. La app local igualmente funciona.');
    for(const n of nets) console.log(`  ${n.name}: ${n.url}`);
    console.log('\nIMPORTANTE: esta ventana debe permanecer abierta durante la clase.');
    console.log('El QR se configura dentro del panel Profesor.');
    console.log('======================================================\n');
    setTimeout(()=>openBrowser(teacherUrl),500);
  };
  server.once('error',onError);server.once('listening',onListen);server.listen(ACTIVE_PORT,HOST);
}
startListening(ACTIVE_PORT);
