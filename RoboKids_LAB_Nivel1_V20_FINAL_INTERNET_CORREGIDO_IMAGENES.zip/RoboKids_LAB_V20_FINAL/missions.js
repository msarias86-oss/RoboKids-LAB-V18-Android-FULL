'use strict';
module.exports = [
  {
    "id": 1,
    "title": "Misión 1 · Primer movimiento",
    "stage": "Explorar · Decidir · Programar",
    "subtitle": "Hacer que RoboCar salga de INICIO y avance hacia la META.",
    "question": {
      "title": "¿Qué hace primero?",
      "subtitle": "El auto está quieto en la línea de salida.",
      "options": [
        [
          "front",
          "⬆️ AVANZAR"
        ],
        [
          "back",
          "⬇️ RETROCEDER"
        ],
        [
          "turn",
          "↪️ GIRAR"
        ],
        [
          "stop",
          "🛑 DETENER"
        ]
      ],
      "correct": "front",
      "explanation": "La primera instrucción debe ser AVANZAR porque queremos salir hacia la meta."
    },
    "teacher": "Presentá el robot y explicá que una secuencia es un conjunto de instrucciones dadas en orden.",
    "program": {
      "concepts": [
        "Evento",
        "Secuencia",
        "Tiempo",
        "Movimiento"
      ],
      "blocks": [
        "al iniciar programa",
        "Car moves FRONT · velocidad 100",
        "esperar 2 segundos",
        "Car moves STOP"
      ],
      "params": [
        [
          "Velocidad",
          "100 como punto de partida"
        ],
        [
          "Tiempo",
          "2 s como valor de calibración"
        ]
      ],
      "steps": [
        "Abrir ACECode en modo Upload.",
        "Agregar la extensión Smart Car.",
        "Construir los cuatro bloques en orden.",
        "Cargar al ESP32 MAX V1.0 por USB.",
        "Probar sobre una pista marcada."
      ],
      "observe": "¿El auto queda corto, llega justo o se pasa?",
      "error": "Cambiar velocidad y tiempo al mismo tiempo impide saber qué ajuste produjo la mejora.",
      "question": "Si se pasa de la meta, ¿qué variable conviene cambiar primero?",
      "success": "El auto sale desde INICIO y se detiene cerca de la META de forma repetible."
    }
  },
  {
    "id": 2,
    "title": "Misión 2 · Ida y vuelta",
    "stage": "Secuencia · Dirección · Pausa",
    "subtitle": "Salir de la base, detenerse y regresar.",
    "question": {
      "title": "¿Cómo vuelve a la BASE?",
      "subtitle": "Después de avanzar y detenerse, ¿qué necesitamos?",
      "options": [
        [
          "back",
          "⬇️ RETROCEDER"
        ],
        [
          "front",
          "⬆️ AVANZAR"
        ],
        [
          "turn",
          "🌀 GIRAR"
        ]
      ],
      "correct": "back",
      "explanation": "Para volver manteniendo la misma orientación, debe retroceder."
    },
    "teacher": "Marcá BASE y PUNTO B. Pedí que anticipen el recorrido antes de programar.",
    "program": {
      "concepts": [
        "Secuencia",
        "Dirección",
        "Pausa"
      ],
      "blocks": [
        "al iniciar programa",
        "FRONT · velocidad 100",
        "esperar 1,5 s",
        "STOP",
        "esperar 0,5 s",
        "BACK · velocidad 100",
        "esperar 1,5 s",
        "STOP"
      ],
      "params": [
        [
          "Velocidad",
          "100"
        ],
        [
          "Ida/Vuelta",
          "1,5 s"
        ],
        [
          "Pausa",
          "0,5 s"
        ]
      ],
      "steps": [
        "Programar primero la ida.",
        "Agregar STOP y una pausa visible.",
        "Programar la vuelta con BACK.",
        "Probar y ajustar solo el tiempo."
      ],
      "observe": "Comparar la distancia de ida y de vuelta.",
      "error": "Olvidar detener el auto antes de invertir el movimiento.",
      "question": "¿Por qué conviene colocar STOP antes de BACK?",
      "success": "El auto regresa cerca del punto inicial sin cambiar su orientación."
    }
  },
  {
    "id": 3,
    "title": "Misión 3 · Giro de 90°",
    "stage": "Orientación · Calibración",
    "subtitle": "Entrar a un camino ubicado a la derecha.",
    "question": {
      "title": "La META está a la derecha",
      "subtitle": "¿Qué movimiento usamos?",
      "options": [
        [
          "cw",
          "↻ GIRO HORARIO"
        ],
        [
          "ccw",
          "↺ GIRO ANTIHORARIO"
        ],
        [
          "back",
          "⬇️ RETROCEDER"
        ]
      ],
      "correct": "cw",
      "explanation": "Para orientar el frente hacia la derecha usamos giro horario."
    },
    "teacher": "Armá una esquina en L con cinta y explicá que un giro cambia la orientación.",
    "program": {
      "concepts": [
        "Dirección",
        "Orientación",
        "Prueba y error"
      ],
      "blocks": [
        "al iniciar programa",
        "girar CLOCKWISE · velocidad 80",
        "esperar 0,6 s",
        "STOP"
      ],
      "params": [
        [
          "Velocidad giro",
          "80"
        ],
        [
          "Tiempo inicial",
          "0,6 s"
        ]
      ],
      "steps": [
        "Marcar 90° en la pista.",
        "Probar un tiempo corto.",
        "Ajustar de a 0,1 s.",
        "Registrar el valor que mejor repite el giro."
      ],
      "observe": "El frente del auto debe quedar alineado con la nueva dirección.",
      "error": "Usar un tiempo demasiado largo y pasarse del ángulo.",
      "question": "¿Qué conviene modificar para calibrar el ángulo: tiempo o ambos parámetros?",
      "success": "El giro queda aproximadamente a 90° en dos intentos consecutivos."
    }
  },
  {
    "id": 4,
    "title": "Misión 4 · Movimiento Mecanum",
    "stage": "Movimiento lateral",
    "subtitle": "Desplazarse lateralmente sin cambiar el frente.",
    "question": {
      "title": "¿Cómo nos movemos de costado?",
      "subtitle": "Queremos desplazarnos lateralmente.",
      "options": [
        [
          "left",
          "⬅️ IZQUIERDA"
        ],
        [
          "front",
          "⬆️ ADELANTE"
        ],
        [
          "cw",
          "↻ GIRAR"
        ]
      ],
      "correct": "left",
      "explanation": "Las ruedas Mecanum permiten desplazamiento lateral sin rotar el robot."
    },
    "teacher": "Mostrá la diferencia entre girar y trasladarse lateralmente.",
    "program": {
      "concepts": [
        "Movimiento Mecanum",
        "Dirección"
      ],
      "blocks": [
        "al iniciar programa",
        "mover lateral LEFT · velocidad 80",
        "esperar 1 s",
        "STOP"
      ],
      "params": [
        [
          "Velocidad",
          "80"
        ],
        [
          "Tiempo",
          "1 s"
        ]
      ],
      "steps": [
        "Marcar un carril lateral.",
        "Programar traslación lateral.",
        "Observar si conserva la orientación.",
        "Ajustar tiempo para estacionar dentro del área."
      ],
      "observe": "El robot debe conservar el frente durante el desplazamiento.",
      "error": "Confundir giro a la izquierda con movimiento lateral a la izquierda.",
      "question": "¿Qué cambia entre “girar” y “moverse lateralmente”?",
      "success": "El auto entra lateralmente al área marcada sin rotar de forma significativa."
    }
  },
  {
    "id": 5,
    "title": "Misión 5 · Repetir y hacer un cuadrado",
    "stage": "Bucles",
    "subtitle": "Usar REPETIR para evitar copiar instrucciones.",
    "question": {
      "title": "¿Qué bloque evita repetir el mismo código?",
      "subtitle": "Necesitamos hacer cuatro lados iguales.",
      "options": [
        [
          "repeat",
          "🔁 REPETIR 4"
        ],
        [
          "wait",
          "⏱️ ESPERAR"
        ],
        [
          "if",
          "🔀 SI"
        ]
      ],
      "correct": "repeat",
      "explanation": "REPETIR ejecuta varias veces el mismo conjunto de instrucciones."
    },
    "teacher": "Compará un programa largo con otro que usa un bucle.",
    "program": {
      "concepts": [
        "Bucle",
        "Repetición",
        "Geometría"
      ],
      "blocks": [
        "al iniciar programa",
        "REPETIR 4 VECES",
        "  FRONT · velocidad 90",
        "  esperar 1 s",
        "  STOP",
        "  giro horario",
        "  esperar tiempo calibrado",
        "  STOP"
      ],
      "params": [
        [
          "Repeticiones",
          "4"
        ],
        [
          "Velocidad avance",
          "90"
        ],
        [
          "Giro",
          "usar valor calibrado en Misión 3"
        ]
      ],
      "steps": [
        "Crear el bloque REPETIR.",
        "Colocar dentro avance y giro.",
        "Cerrar cada tramo con STOP.",
        "Probar el cuadrado completo."
      ],
      "observe": "El último punto debería quedar cerca del inicio.",
      "error": "Poner el giro fuera del bloque REPETIR.",
      "question": "¿Qué ventaja tiene el bucle frente a copiar cuatro veces el mismo código?",
      "success": "El auto completa cuatro lados y cuatro giros de forma reconocible."
    }
  },
  {
    "id": 6,
    "title": "Misión 6 · Circuito zigzag",
    "stage": "Algoritmo",
    "subtitle": "Combinar rectas y giros para atravesar un circuito.",
    "question": {
      "title": "¿Qué necesitamos primero?",
      "subtitle": "Antes de programar un circuito complejo.",
      "options": [
        [
          "plan",
          "🧠 PLANIFICAR LA SECUENCIA"
        ],
        [
          "speed",
          "⚡ SUBIR VELOCIDAD"
        ],
        [
          "random",
          "🎲 PROBAR AL AZAR"
        ]
      ],
      "correct": "plan",
      "explanation": "Primero descomponemos el recorrido en pasos y luego programamos."
    },
    "teacher": "Pedí dibujar flechas sobre el circuito antes de tocar ACECode.",
    "program": {
      "concepts": [
        "Algoritmo",
        "Descomposición",
        "Secuencia"
      ],
      "blocks": [
        "al iniciar programa",
        "FRONT · tramo A",
        "giro derecha",
        "FRONT · tramo B",
        "giro izquierda",
        "FRONT · tramo C",
        "STOP"
      ],
      "params": [
        [
          "Velocidad",
          "70–90"
        ],
        [
          "Tiempos",
          "medir cada tramo"
        ]
      ],
      "steps": [
        "Dibujar el recorrido.",
        "Nombrar cada tramo.",
        "Programar un tramo por vez.",
        "Integrar todo recién al final."
      ],
      "observe": "Identificar exactamente en qué tramo aparece el error.",
      "error": "Cambiar todo el programa cuando solo falla un tramo.",
      "question": "¿Cómo podemos dividir un problema grande en problemas pequeños?",
      "success": "El auto atraviesa el zigzag sin salir de los límites principales."
    }
  },
  {
    "id": 7,
    "title": "Misión 7 · Sensor ultrasónico",
    "stage": "Sensores",
    "subtitle": "Detenerse al detectar un obstáculo.",
    "question": {
      "title": "¿Qué dato necesita el robot?",
      "subtitle": "Para saber si hay un objeto adelante.",
      "options": [
        [
          "distance",
          "📏 DISTANCIA"
        ],
        [
          "color",
          "🎨 COLOR"
        ],
        [
          "time",
          "⏱️ HORA"
        ]
      ],
      "correct": "distance",
      "explanation": "El sensor ultrasónico mide distancia al obstáculo."
    },
    "teacher": "Explicá entrada → decisión → salida: sensor mide, programa decide, motor actúa.",
    "program": {
      "concepts": [
        "Sensor",
        "Entrada",
        "Umbral"
      ],
      "blocks": [
        "al iniciar programa",
        "POR SIEMPRE",
        "  leer distancia ultrasónica",
        "  SI distancia < 20 cm",
        "     STOP",
        "  SI NO",
        "     FRONT · velocidad 70"
      ],
      "params": [
        [
          "Umbral",
          "20 cm"
        ],
        [
          "Velocidad",
          "70"
        ]
      ],
      "steps": [
        "Verificar lectura del ultrasónico.",
        "Mostrar distancia en ACECode si está disponible.",
        "Agregar condición de 20 cm.",
        "Probar con un objeto grande."
      ],
      "observe": "El robot debe detenerse antes de tocar el obstáculo.",
      "error": "Usar un umbral demasiado pequeño.",
      "question": "¿Qué ocurre si cambiamos 20 cm por 40 cm?",
      "success": "Se detiene de forma consistente antes del obstáculo."
    }
  },
  {
    "id": 8,
    "title": "Misión 8 · SI / SI NO",
    "stage": "Condicionales",
    "subtitle": "Tomar una decisión según el sensor.",
    "question": {
      "title": "Si no hay obstáculo, ¿qué debe hacer?",
      "subtitle": "La distancia es mayor al umbral.",
      "options": [
        [
          "front",
          "⬆️ AVANZAR"
        ],
        [
          "stop",
          "🛑 DETENER"
        ],
        [
          "back",
          "⬇️ RETROCEDER"
        ]
      ],
      "correct": "front",
      "explanation": "SI NO hay obstáculo cerca, el robot puede avanzar."
    },
    "teacher": "Representá el condicional con una pregunta cotidiana: “si llueve, paraguas; si no, sigo”.",
    "program": {
      "concepts": [
        "Condicional",
        "SI / SI NO",
        "Lógica"
      ],
      "blocks": [
        "POR SIEMPRE",
        "SI distancia < 20 cm",
        "  STOP",
        "  BACK 0,4 s",
        "  giro derecha 0,5 s",
        "SI NO",
        "  FRONT 70"
      ],
      "params": [
        [
          "Umbral",
          "20 cm"
        ],
        [
          "Retroceso",
          "0,4 s"
        ],
        [
          "Giro",
          "0,5 s inicial"
        ]
      ],
      "steps": [
        "Partir del programa de Misión 7.",
        "Agregar una acción de escape.",
        "Agregar la rama SI NO.",
        "Probar con obstáculos en distintas posiciones."
      ],
      "observe": "Debe cambiar de comportamiento según la distancia.",
      "error": "Olvidar la rama SI NO y dejar el robot detenido para siempre.",
      "question": "¿Qué dos caminos posibles tiene esta decisión?",
      "success": "Avanza libremente y ejecuta maniobra de escape cuando detecta obstáculo."
    }
  },
  {
    "id": 9,
    "title": "Misión 9 · Seguidor de línea",
    "stage": "Sensores de línea",
    "subtitle": "Seguir un recorrido marcado en el piso.",
    "question": {
      "title": "¿Qué debe observar el robot?",
      "subtitle": "Para permanecer sobre el camino.",
      "options": [
        [
          "line",
          "⬛⬜ CONTRASTE DE LÍNEA"
        ],
        [
          "ultra",
          "📡 DISTANCIA"
        ],
        [
          "wifi",
          "📶 WIFI"
        ]
      ],
      "correct": "line",
      "explanation": "El seguidor usa sensores inferiores para distinguir línea y fondo."
    },
    "teacher": "Mostrá los sensores inferiores y la diferencia entre línea oscura y fondo claro.",
    "program": {
      "concepts": [
        "Sensor de línea",
        "Corrección",
        "Retroalimentación"
      ],
      "blocks": [
        "POR SIEMPRE",
        "leer sensor izquierdo y derecho",
        "si ambos centrados → FRONT",
        "si se desvía izquierda → corregir derecha",
        "si se desvía derecha → corregir izquierda"
      ],
      "params": [
        [
          "Velocidad",
          "60–80"
        ],
        [
          "Contraste",
          "usar pista bien definida"
        ]
      ],
      "steps": [
        "Calibrar sobre fondo y línea.",
        "Probar recta primero.",
        "Agregar una curva amplia.",
        "Reducir velocidad si oscila."
      ],
      "observe": "Debe hacer pequeñas correcciones continuamente.",
      "error": "Usar demasiada velocidad y perder la línea en curvas.",
      "question": "¿Por qué el robot necesita medir muchas veces y no una sola?",
      "success": "Completa el circuito de línea sin ayuda manual."
    }
  },
  {
    "id": 10,
    "title": "Misión 10 · Desafío final RoboKids LAB",
    "stage": "Integración",
    "subtitle": "Combinar lo aprendido en una misión final.",
    "question": {
      "title": "¿Cuál es la mejor estrategia?",
      "subtitle": "Tenemos un desafío con rectas, giro, obstáculo y meta.",
      "options": [
        [
          "parts",
          "🧩 DIVIDIR EN PARTES"
        ],
        [
          "all",
          "🚀 PROGRAMAR TODO DE UNA"
        ],
        [
          "max",
          "⚡ VELOCIDAD MÁXIMA"
        ]
      ],
      "correct": "parts",
      "explanation": "Dividir el desafío permite probar y corregir cada parte por separado."
    },
    "teacher": "Dejá que cada equipo diseñe su algoritmo antes de programarlo.",
    "program": {
      "concepts": [
        "Integración",
        "Algoritmo",
        "Mejora continua"
      ],
      "blocks": [
        "PLANIFICAR",
        "PROGRAMAR POR TRAMOS",
        "PROBAR CADA TRAMO",
        "INTEGRAR",
        "AJUSTAR",
        "VALIDAR"
      ],
      "params": [
        [
          "Velocidad",
          "según tramo"
        ],
        [
          "Sensores",
          "según desafío"
        ],
        [
          "Criterio",
          "llegar a meta sin intervención"
        ]
      ],
      "steps": [
        "Dibujar algoritmo.",
        "Asignar roles en el equipo.",
        "Programar por módulos.",
        "Realizar prueba completa.",
        "Corregir solo el punto que falla."
      ],
      "observe": "Evaluar estabilidad, precisión y trabajo del equipo.",
      "error": "Cambiar varias cosas a la vez después de una falla.",
      "question": "¿Qué aprendimos sobre pensar, programar, probar y mejorar?",
      "success": "El equipo completa el desafío y puede explicar qué hizo su programa."
    }
  },
  {
    "id": 11,
    "title": "Misión 11 · Conocer el brazo robótico",
    "stage": "Explorar · Decidir · Programar",
    "subtitle": "Reconocer cómo abrir y cerrar la garra desde bloques y control WiFi.",
    "question": {
      "title": "¿Qué acción permite atrapar un objeto?",
      "subtitle": "Queremos tomar un bloque con la garra del brazo.",
      "options": [
        [
          "open",
          "🖐️ ABRIR GARRA"
        ],
        [
          "close",
          "✊ CERRAR GARRA"
        ],
        [
          "left",
          "↩️ GIRAR IZQUIERDA"
        ],
        [
          "memory",
          "💾 GUARDAR MEMORIA"
        ]
      ],
      "correct": "close",
      "explanation": "Para atrapar el objeto, la garra debe cerrarse suavemente cuando está bien posicionada."
    },
    "teacher": "Explicá que el brazo puede controlarse desde una página web o app WiFi y que la garra sirve para tomar y soltar objetos con seguridad.",
    "program": {
      "concepts": [
        "Brazo robótico",
        "Garra",
        "Secuencia",
        "Control WiFi"
      ],
      "blocks": [
        "al iniciar programa",
        "Brazo HOME / posición inicial",
        "abrir garra",
        "mover brazo al objeto",
        "cerrar garra",
        "esperar 1 segundo"
      ],
      "params": [
        [
          "Velocidad",
          "suave para evitar golpes"
        ],
        [
          "Garra",
          "abrir antes de acercarse al objeto"
        ]
      ],
      "steps": [
        "Abrir la extensión o control web del brazo mecánico.",
        "Llevar el brazo a posición inicial (HOME).",
        "Abrir la garra antes de acercarse al objeto.",
        "Mover la garra hasta el objeto.",
        "Cerrar la garra suavemente para atraparlo.",
        "Guardar y probar el movimiento."
      ],
      "observe": "Si la garra llega alineada y el objeto queda sujeto sin caerse.",
      "error": "Cerrar la garra antes de tiempo o con demasiada fuerza puede hacer fallar la captura.",
      "question": "¿Conviene abrir la garra antes de acercarse al objeto? ¿Por qué?",
      "success": "La garra atrapa el objeto y lo sostiene con estabilidad.",
      "imageKey": "arm_car",
      "imageTitle": "Auto con brazo mecánico",
      "imageNote": "El brazo incluye garra antideslizante, control web/app WiFi y movimientos suaves con protección de límite."
    },
    "explain": [
      "La garra puede abrirse y cerrarse para tomar piezas.",
      "Los movimientos deben ser suaves y ordenados.",
      "El brazo se puede controlar desde la web o app WiFi."
    ],
    "challenge": "Capturá un bloque liviano usando solo movimientos lentos y ordenados.",
    "physical": [
      "Garra abre",
      "Garra cierra",
      "Objeto atrapado"
    ],
    "retro": "Aprendimos que la garra necesita una secuencia correcta: abrir, acercarse y cerrar.",
    "questionGuide": "¿Qué bloque usarías primero para no golpear el objeto?",
    "success": "El equipo toma y mantiene el objeto con la garra."
  },
  {
    "id": 12,
    "title": "Misión 12 · Tomar y soltar objetos",
    "stage": "Programación · Prueba física",
    "subtitle": "Mover el brazo en 3 ejes para levantar y dejar un objeto en otra zona.",
    "question": {
      "title": "¿Cuál es la mejor secuencia para mover el objeto?",
      "subtitle": "El objetivo es tomar una pieza y dejarla en la meta.",
      "options": [
        [
          "seq1",
          "🧩 ABRIR → BAJAR → CERRAR → LEVANTAR → SOLTAR"
        ],
        [
          "seq2",
          "🚀 CERRAR → GIRAR → ABRIR"
        ],
        [
          "seq3",
          "🎯 SOLO GIRAR LA BASE"
        ],
        [
          "seq4",
          "🔁 REPETIR SIN PROBAR"
        ]
      ],
      "correct": "seq1",
      "explanation": "La secuencia correcta primero posiciona la garra, luego toma el objeto, lo levanta y finalmente lo suelta en la meta."
    },
    "teacher": "Mostrá que el brazo se mueve en 3 ejes: giro de base, altura y alcance. Relacioná esto con el espacio y la planificación del movimiento.",
    "program": {
      "concepts": [
        "3 ejes",
        "Coordenadas simples",
        "Secuencia",
        "Soltar objeto"
      ],
      "blocks": [
        "al iniciar programa",
        "girar base al objeto",
        "bajar brazo",
        "cerrar garra",
        "subir brazo",
        "girar base a la meta",
        "abrir garra"
      ],
      "params": [
        [
          "Altura",
          "bajar solo lo necesario"
        ],
        [
          "Alcance",
          "avanzar despacio hasta tocar la pieza"
        ]
      ],
      "steps": [
        "Llevar el brazo a HOME.",
        "Girar la base hacia el objeto.",
        "Bajar el brazo hasta la altura correcta.",
        "Cerrar la garra para sujetar la pieza.",
        "Subir el brazo para despejar obstáculos.",
        "Girar la base hacia la zona de entrega.",
        "Abrir la garra para soltar la pieza."
      ],
      "observe": "Si el brazo mantiene estable la pieza durante el traslado y la deja en el lugar correcto.",
      "error": "Mover varios ejes demasiado rápido hace que el objeto se deslice o caiga.",
      "question": "¿Qué conviene hacer antes de girar con el objeto: subir o bajar el brazo?",
      "success": "La pieza llega a la zona objetivo y es soltada correctamente.",
      "imageKey": "arm_car",
      "imageTitle": "Referencia del brazo en 3 ejes",
      "imageNote": "Trabajamos base, altura y alcance para desplazar objetos entre dos zonas."
    },
    "explain": [
      "El brazo se mueve en 3 ejes espaciales.",
      "Primero se atrapa el objeto y después se transporta.",
      "Moverse con suavidad mejora la estabilidad."
    ],
    "challenge": "Tomá una pieza y colócala dentro de una caja o sobre una marca de color.",
    "physical": [
      "Objeto tomado",
      "Objeto trasladado",
      "Objeto soltado"
    ],
    "retro": "Aprendimos que mover objetos requiere planificar el camino del brazo y la altura.",
    "questionGuide": "¿Cómo podés evitar que el objeto se caiga durante el giro?",
    "success": "El equipo deposita la pieza en la meta sin asistencia manual."
  },
  {
    "id": 13,
    "title": "Misión 13 · Modo memoria",
    "stage": "Explorar · Programar · Resultados",
    "subtitle": "Grabar una secuencia del brazo y repetirla automáticamente.",
    "question": {
      "title": "¿Para qué sirve el modo memoria?",
      "subtitle": "El brazo repite movimientos que ya fueron enseñados.",
      "options": [
        [
          "repeat",
          "🔁 REPETIR MOVIMIENTOS GRABADOS"
        ],
        [
          "faster",
          "⚡ IR MÁS RÁPIDO"
        ],
        [
          "stop",
          "🛑 APAGAR EL BRAZO"
        ],
        [
          "random",
          "🎲 MOVERSE AL AZAR"
        ]
      ],
      "correct": "repeat",
      "explanation": "El modo memoria permite registrar una secuencia y volver a ejecutarla sin programarla de nuevo paso por paso."
    },
    "teacher": "Explicá que grabar y repetir es una forma simple de automatización: una vez enseñado el camino, el robot puede repetirlo.",
    "program": {
      "concepts": [
        "Memoria",
        "Repetición",
        "Automatización",
        "Secuencia"
      ],
      "blocks": [
        "activar modo memoria",
        "mover base",
        "bajar brazo",
        "cerrar garra",
        "subir brazo",
        "abrir garra",
        "reproducir secuencia"
      ],
      "params": [
        [
          "Cantidad de pasos",
          "pocos y claros para niños de nivel 1"
        ],
        [
          "Velocidad",
          "media o suave para repetir con estabilidad"
        ]
      ],
      "steps": [
        "Activar el modo memoria.",
        "Realizar manualmente o con bloques una secuencia simple.",
        "Guardar la secuencia.",
        "Llevar el brazo a HOME.",
        "Reproducir la secuencia guardada.",
        "Observar si repite el movimiento de forma parecida."
      ],
      "observe": "Si la repetición conserva el orden y la estabilidad de los movimientos.",
      "error": "Grabar una secuencia muy larga o muy rápida dificulta que el niño entienda qué está pasando.",
      "question": "¿Qué ventaja tiene guardar una secuencia si queremos repetir la misma tarea varias veces?",
      "success": "El brazo repite la secuencia guardada con resultado similar.",
      "imageKey": "arm_car",
      "imageTitle": "Modo memoria del brazo",
      "imageNote": "El brazo puede repetir movimientos grabados para automatizar tareas simples."
    },
    "explain": [
      "El modo memoria permite enseñar una secuencia y repetirla.",
      "Repetir es una forma inicial de automatización.",
      "Guardar pocos pasos ayuda a entender el proceso."
    ],
    "challenge": "Grabá una secuencia de tomar y soltar una pieza y repetila dos veces.",
    "physical": [
      "Secuencia grabada",
      "Secuencia repetida"
    ],
    "retro": "Aprendimos que un robot puede repetir una tarea cuando la secuencia fue guardada correctamente.",
    "questionGuide": "¿Qué pasaría si cambiamos el lugar del objeto después de grabar la secuencia?",
    "success": "La secuencia se reproduce correctamente al menos una vez."
  },
  {
    "id": 14,
    "title": "Misión 14 · Desafío final combinado",
    "stage": "Integración total",
    "subtitle": "Combinar auto + brazo + traslado de objeto hasta la meta final.",
    "question": {
      "title": "¿Cuál es la mejor estrategia final?",
      "subtitle": "El robot debe moverse, tomar un objeto y dejarlo en la meta.",
      "options": [
        [
          "parts",
          "🧩 DIVIDIR EN PARTES"
        ],
        [
          "random",
          "🎲 PROBAR AL AZAR"
        ],
        [
          "speed",
          "⚡ IR MÁS RÁPIDO"
        ],
        [
          "one",
          "📦 HACER TODO EN UN SOLO PASO"
        ]
      ],
      "correct": "parts",
      "explanation": "La mejor forma es dividir el problema: mover el auto, posicionar el brazo, tomar el objeto y trasladarlo paso a paso."
    },
    "teacher": "Guiá la integración final: primero el recorrido del auto, luego la secuencia del brazo, y finalmente la entrega del objeto en la meta.",
    "program": {
      "concepts": [
        "Integración",
        "Planificación",
        "Auto + brazo",
        "Secuencia completa"
      ],
      "blocks": [
        "al iniciar programa",
        "auto FRONT hasta zona de toma",
        "STOP",
        "brazo HOME",
        "abrir garra",
        "bajar brazo",
        "cerrar garra",
        "subir brazo",
        "auto BACK o giro hacia meta",
        "STOP",
        "abrir garra en la meta"
      ],
      "params": [
        [
          "Velocidad del auto",
          "70–90"
        ],
        [
          "Giro/tiempo",
          "calibrados previamente"
        ],
        [
          "Garra",
          "movimientos suaves para no perder la pieza"
        ]
      ],
      "steps": [
        "Dividir la misión en cuatro partes: desplazamiento, toma, traslado y entrega.",
        "Programar primero el auto para llegar a la zona del objeto.",
        "Agregar la secuencia del brazo para atrapar la pieza.",
        "Programar el movimiento final del auto o del brazo hacia la meta.",
        "Abrir la garra para soltar la pieza en el objetivo.",
        "Probar y ajustar solo una parte por vez."
      ],
      "observe": "Si el auto llega bien posicionado y el brazo logra tomar y entregar el objeto sin caerse.",
      "error": "Intentar corregir todo al mismo tiempo cuando falla solo una parte de la secuencia.",
      "question": "¿Qué parte conviene ajustar primero si el objeto no llega a la meta?",
      "success": "El equipo completa el recorrido, atrapa el objeto y lo deposita en la meta.",
      "imageKey": "arm_car",
      "imageTitle": "Auto + brazo mecánico",
      "imageNote": "Misión integradora: movimiento del auto, captura con garra y traslado del objeto a la meta."
    },
    "explain": [
      "La misión final combina movimiento, sensores simples y control del brazo.",
      "Resolver por partes facilita encontrar errores.",
      "Pensar, programar, probar y mejorar sigue siendo la estrategia central."
    ],
    "challenge": "Mover el auto hasta la zona de toma, capturar un bloque y dejarlo en la meta final.",
    "physical": [
      "Auto llega a zona",
      "Objeto atrapado",
      "Objeto trasladado",
      "Objeto soltado en meta"
    ],
    "retro": "El desafío final muestra cómo varios subsistemas del robot pueden trabajar juntos.",
    "questionGuide": "¿Cómo dividirías esta misión para que sea más fácil de programar?",
    "success": "El objeto es trasladado con éxito desde el inicio hasta la meta final."
  }
];
