@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RoboKids LAB V20 - SERVIDOR
color 1F

echo ======================================================
echo   ROBOKIDS LAB V20 - INICIO CON UN SOLO DOBLE CLICK
echo ======================================================
echo.

where node.exe >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js no esta instalado o no esta en PATH.
  echo Instala Node.js LTS y vuelve a abrir RoboKids LAB.
  echo.
  pause
  exit /b 1
)

if not exist "%~dp0server.js" goto :missing
if not exist "%~dp0missions.js" goto :missing
if not exist "%~dp0public\index.html" goto :missing
if not exist "%~dp0vendor\QRCode\index.js" goto :missing

rem Si ya existe una instancia RoboKids activa, abrirla sin crear otra.
if exist "%~dp0data\PORT.txt" (
  set "RKPORT="
  set /p RKPORT=<"%~dp0data\PORT.txt"
  if defined RKPORT (
    powershell.exe -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 'http://127.0.0.1:%RKPORT%/health'; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
    if not errorlevel 1 (
      echo [OK] RoboKids LAB ya esta ejecutandose en puerto %RKPORT%.
      rundll32.exe url.dll,FileProtocolHandler "http://127.0.0.1:%RKPORT%/?role=teacher"
      exit /b 0
    )
  )
)

echo [OK] Iniciando RoboKids LAB...
echo Esta ventana debe permanecer abierta mientras dure la clase.
echo.
node.exe "%~dp0server.js"

echo.
echo ======================================================
echo EL SERVIDOR SE DETUVO.
echo Si no lo cerraste vos, revisa el mensaje de arriba.
echo ======================================================
pause
exit /b 0

:missing
echo [ERROR] Faltan archivos del paquete RoboKids LAB.
echo Descomprime TODO el ZIP en una carpeta antes de usarlo.
pause
exit /b 1
