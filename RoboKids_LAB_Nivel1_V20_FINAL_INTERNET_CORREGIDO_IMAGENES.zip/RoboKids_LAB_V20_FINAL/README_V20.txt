ROBOKIDS LAB V20 REALTIME
========================

NOVEDAD PRINCIPAL V20
- El alumno puede ingresar desde Android/Chrome e iPhone/iPad/Safari mediante QR.
- Al crear una sala, la Misión 1 queda en fase RESPONDER automáticamente.
- Las opciones de respuesta son táctiles y grandes.
- Al tocar una opción aparece RESPUESTA ENVIADA y queda marcada.
- El alumno puede cambiar su respuesta mientras el profesor no haya revelado la solución.
- Cada respuesta queda vinculada a clientId + participante + equipo + misión.
- El puntaje se calcula por mayoría de cada equipo cuando el profesor pulsa REVELAR Y PUNTUAR.

INICIO WINDOWS
1. Descomprimir todo el ZIP.
2. Ejecutar 1_ABRIR_APP_V20_WINDOWS.bat.
3. Crear sala desde Profesor.
4. Escanear QR con Android/Chrome o iPhone/Safari.
5. El alumno ingresa nombre/equipo y pulsa INGRESAR Y RESPONDER.
6. La pregunta aparece activa de inmediato.

Si el profesor cambia de fase, las respuestas se bloquean. Para volver a habilitarlas, seleccionar RESPONDER.
