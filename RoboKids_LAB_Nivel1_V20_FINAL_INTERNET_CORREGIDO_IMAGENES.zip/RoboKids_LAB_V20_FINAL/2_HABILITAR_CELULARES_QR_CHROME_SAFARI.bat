@echo off
net session >nul 2>&1
if errorlevel 1 (
  echo Se necesitan permisos de Administrador para habilitar acceso desde celulares.
  pause
  exit /b 1
)
netsh advfirewall firewall delete rule name="RoboKids LAB V20 Acceso Movil" >nul 2>&1
netsh advfirewall firewall add rule name="RoboKids LAB V20 Acceso Movil" dir=in action=allow protocol=TCP localport=3000-3010 profile=any >nul
if errorlevel 1 (
  echo No se pudo crear la regla de firewall.
  pause
  exit /b 1
)
echo Acceso habilitado para Google Chrome Android, Safari iPhone/iPad y otros dispositivos en TCP 3000-3010.
echo Todos los dispositivos deben estar en la misma red Wi-Fi sin aislamiento de clientes.
timeout /t 3 /nobreak >nul
