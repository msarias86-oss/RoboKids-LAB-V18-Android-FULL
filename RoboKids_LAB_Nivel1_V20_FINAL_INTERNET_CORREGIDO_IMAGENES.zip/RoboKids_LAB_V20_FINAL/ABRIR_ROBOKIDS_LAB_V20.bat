@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0ABRIR_ROBOKIDS_LAB_V20_INTERNET.bat"
exit /b %errorlevel%
