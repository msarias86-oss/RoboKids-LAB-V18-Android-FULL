#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js no esta instalado. Instale Node.js LTS."
  exit 1
fi
rm -f data/server-info.json
node server.js > robokids_server.log 2>&1 &
PID=$!
for i in {1..30}; do
  if [ -f data/server-info.json ]; then
    PORT=$(node -e "try{console.log(require('./data/server-info.json').port)}catch(e){}")
    if [ -n "$PORT" ] && curl -fsS "http://127.0.0.1:${PORT}/health" | grep -q 'V20-CHROME-ANDROID-FULL-ACCESS'; then
      URL="http://127.0.0.1:${PORT}/?role=teacher"
      echo "RoboKids listo en $URL"
      if command -v open >/dev/null 2>&1; then open "$URL"; fi
      if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"; fi
      exit 0
    fi
  fi
  sleep 1
done
echo "El servidor no respondio. Revise robokids_server.log"
kill "$PID" 2>/dev/null || true
exit 1
