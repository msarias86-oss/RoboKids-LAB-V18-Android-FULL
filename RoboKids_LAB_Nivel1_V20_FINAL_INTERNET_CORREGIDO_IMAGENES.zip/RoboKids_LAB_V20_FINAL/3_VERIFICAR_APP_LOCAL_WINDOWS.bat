@echo off
setlocal
cd /d "%~dp0"
title RoboKids LAB V20 - Verificar acceso local

echo ==============================================
echo VERIFICACION LOCAL ROBOKIDS LAB V20
echo ==============================================
echo.
where node
node -v 2>nul
echo.
if exist "data\PORT.txt" (
  set /p PORT=<"data\PORT.txt"
) else (
  set PORT=3000
)
echo Puerto registrado: %PORT%
echo.
echo Probando http://127.0.0.1:%PORT%/health
curl.exe -s --max-time 5 "http://127.0.0.1:%PORT%/health"
echo.
echo.
echo Si arriba aparece "ok":true, el servidor local funciona.
echo Abrir manualmente:
echo http://127.0.0.1:%PORT%/?role=teacher
echo.
pause
