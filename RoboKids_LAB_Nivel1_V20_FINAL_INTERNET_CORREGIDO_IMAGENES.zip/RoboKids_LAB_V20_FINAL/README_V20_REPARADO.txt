ROBOKIDS LAB NIVEL 1 - V20 REALTIME REPARADO
===============================================

ESTA EDICION FUE VERIFICADA EJECUTANDO EL SERVIDOR Y SUS API.

CAMBIOS DE ACCESO
- El panel Profesor se abre usando la IP LAN elegida por el propio servidor, no 127.0.0.1.
- El QR usa exactamente ese mismo host y puerto.
- V20 genera un enlace directo compatible con Chrome Android y Safari, sin depender de una redirección 302.
- /diagnostico muestra enlaces de prueba para cada interfaz de red.
- El iniciador lanza el firewall en segundo plano y no bloquea la apertura local.
- No requiere npm, Express ni Socket.IO. Solo Node.js.

COMO INICIAR
1. Descomprimir TODO el ZIP en una carpeta local.
2. Doble clic en INICIAR_ROBOKIDS_V20_WINDOWS.bat.
3. Aceptar el permiso de Windows Firewall cuando aparezca.
4. El panel Profesor se abre con una URL tipo http://192.168.1.25:3000/?role=teacher.
5. Crear sala y escanear el QR desde la Camara del iPhone.

PRUEBA CHROME ANDROID / SAFARI
Copiar en Chrome Android o Safari la direccion que muestra la consola, por ejemplo:
http://192.168.1.25:3000/api/ping
Debe devolver JSON con "ok":true.

SI /api/ping NO ABRE EN EL CELULAR
La aplicacion ya esta funcionando en la PC, pero la red no permite que el iPhone llegue a ella. Verificar:
- misma Wi-Fi;
- no usar red Guest/Invitados;
- aceptar la regla de firewall;
- desactivar VPN temporalmente;
- si es una red corporativa con aislamiento de clientes, usar hotspot/router local.

DIAGNOSTICO
Abrir en la PC: /diagnostico
O ejecutar DIAGNOSTICO_V20.bat.
