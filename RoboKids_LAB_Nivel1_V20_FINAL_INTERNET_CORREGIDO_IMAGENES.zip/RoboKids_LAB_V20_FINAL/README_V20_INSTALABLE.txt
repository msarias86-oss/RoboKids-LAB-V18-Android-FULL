RoboKids LAB Nivel 1 · V20 INSTALABLE

Mejoras de esta edición:
- Un único instalador de Windows crea el acceso directo con icono y abre la app.
- El acceso directo inicia el servidor automáticamente o reutiliza una instancia ya abierta.
- Icono RoboKids en formato ICO para Windows.
- Iconos 180/192/256/512 PNG para iOS y Android.
- manifest.webmanifest y apple-touch-icon integrados.
- Página /instalar con instrucciones para iPhone/iPad/Android/Windows.
- Se mantiene el acceso QR/Chrome Android/Safari y el flujo de respuesta del alumno de V20.
