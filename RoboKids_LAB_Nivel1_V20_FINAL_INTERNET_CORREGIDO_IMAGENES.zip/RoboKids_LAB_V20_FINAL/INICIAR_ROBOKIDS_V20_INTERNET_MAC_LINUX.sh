#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
DATA="$ROOT/data"; mkdir -p "$DATA"; rm -f "$DATA/PUBLIC_URL.txt"
command -v node >/dev/null || { echo "Node.js no esta instalado"; exit 1; }
NO_BROWSER=1 node "$ROOT/server.js" & SERVER_PID=$!
trap 'kill $SERVER_PID 2>/dev/null || true; [ -n "$TUNNEL_PID" ] && kill $TUNNEL_PID 2>/dev/null || true; rm -f "$DATA/PUBLIC_URL.txt"' EXIT
for i in {1..60}; do [ -s "$DATA/PORT.txt" ] && PORT=$(cat "$DATA/PORT.txt") && curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null 2>&1 && break; sleep .5; done
[ -n "$PORT" ] || { echo "No se pudo iniciar RoboKids"; exit 1; }
if ! command -v cloudflared >/dev/null; then echo "Instala cloudflared para habilitar acceso por Internet, o ejecuta con PUBLIC_URL apuntando a tu hosting HTTPS."; exit 1; fi
cloudflared tunnel --no-autoupdate --url "http://127.0.0.1:$PORT" >"$DATA/cloudflared-output.log" 2>"$DATA/cloudflared-error.log" & TUNNEL_PID=$!
for i in {1..90}; do URL=$(grep -Eho 'https://[A-Za-z0-9-]+\.trycloudflare\.com' "$DATA/cloudflared-output.log" "$DATA/cloudflared-error.log" 2>/dev/null | head -1 || true); [ -n "$URL" ] && break; sleep .5; done
[ -n "$URL" ] || { echo "No se obtuvo URL publica"; exit 1; }
printf '%s' "$URL" > "$DATA/PUBLIC_URL.txt"
echo "RoboKids V20 Internet: $URL"
if command -v open >/dev/null; then open "http://127.0.0.1:$PORT/?role=teacher"; elif command -v xdg-open >/dev/null; then xdg-open "http://127.0.0.1:$PORT/?role=teacher"; fi
wait $SERVER_PID
