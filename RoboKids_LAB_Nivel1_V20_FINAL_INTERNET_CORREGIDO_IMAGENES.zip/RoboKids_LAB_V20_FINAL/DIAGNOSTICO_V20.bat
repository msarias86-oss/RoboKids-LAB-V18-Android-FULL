@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title RoboKids LAB V20 - Diagnostico
echo ==============================================
echo RoboKids LAB V20 - DIAGNOSTICO COMPLETO
echo ==============================================
echo.
echo [1] NODE
where node
node -v 2>nul
echo.
echo [2] ARCHIVOS
for %%F in (server.js missions.js public\index.html vendor\QRCode\index.js) do (
 if exist "%%F" (echo OK  %%F) else (echo FALTA %%F)
)
echo.
echo [3] SERVER INFO
if exist "data\server-info.json" (type "data\server-info.json") else (echo No existe server-info.json - el servidor no inicio.)
echo.
echo [4] PUERTOS 3000-3010
for /L %%P in (3000,1,3010) do netstat -ano | findstr ":%%P " | findstr LISTENING
echo.
echo [5] IP ACTIVAS
ipconfig | findstr /i "IPv4"
echo.
echo [6] LOG DEL SERVIDOR
if exist robokids_server.log (type robokids_server.log) else (echo Sin log.)
echo.
echo [7] PRUEBA LOCAL
set PORT=
if exist "data\server-info.json" for /f "usebackq tokens=*" %%P in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$j=Get-Content -Raw 'data\server-info.json'|ConvertFrom-Json;if($j.port){$j.port}"`) do set PORT=%%P
if defined PORT powershell -NoProfile -ExecutionPolicy Bypass -Command "try{Invoke-RestMethod -TimeoutSec 3 'http://127.0.0.1:!PORT!/api/ping'|ConvertTo-Json}catch{Write-Host $_.Exception.Message}"
echo.
pause
