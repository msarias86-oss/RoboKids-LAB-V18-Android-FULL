package com.robokidslab.nivel1;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.NetworkInterface;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import fi.iki.elonen.NanoHTTPD;

public class EmbeddedRoboKidsServer extends NanoHTTPD {
    private static final String VERSION = "V20-ANDROID-FULL";
    private static final List<String> PHASES = Arrays.asList("briefing", "question", "programming", "testing", "results");
    private static final Team[] TEAMS = new Team[]{
            new Team("azul", "Equipo Azul", "🔵"),
            new Team("verde", "Equipo Verde", "🟢"),
            new Team("naranja", "Equipo Naranja", "🟠"),
            new Team("violeta", "Equipo Violeta", "🟣")
    };

    private final Context context;
    private final Gson gson = new GsonBuilder().disableHtmlEscaping().create();
    private final Map<String, Room> rooms = new ConcurrentHashMap<>();
    private final List<Mission> missions;
    private final File dataFile;
    private final int listeningPort;
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final SecureRandom random = new SecureRandom();

    public static EmbeddedRoboKidsServer startAvailable(Context context, int first, int last) throws IOException {
        IOException lastError = null;
        for (int port = first; port <= last; port++) {
            try {
                EmbeddedRoboKidsServer server = new EmbeddedRoboKidsServer(context, port);
                server.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
                return server;
            } catch (IOException e) {
                lastError = e;
            }
        }
        throw lastError != null ? lastError : new IOException("No hay un puerto disponible");
    }

    private EmbeddedRoboKidsServer(Context context, int port) throws IOException {
        super("0.0.0.0", port);
        this.context = context.getApplicationContext();
        this.listeningPort = port;
        this.dataFile = new File(this.context.getFilesDir(), "robokids_rooms_v20_android.json");
        this.missions = loadMissions();
        loadRooms();
        scheduler.scheduleAtFixedRate(() -> {
            boolean changed = false;
            for (Room room : rooms.values()) {
                boolean before = room.timer.running;
                ensureTimer(room);
                if (before && !room.timer.running) changed = true;
            }
            if (changed) saveRooms();
        }, 500, 500, TimeUnit.MILLISECONDS);
    }

    public int getListeningPort() { return listeningPort; }

    @Override
    public void stop() {
        scheduler.shutdownNow();
        saveRooms();
        super.stop();
    }

    @Override
    public Response serve(IHTTPSession session) {
        try {
            String uri = session.getUri();
            Method method = session.getMethod();

            if (method == Method.GET && "/health".equals(uri)) {
                JsonObject o = baseOk();
                o.addProperty("version", VERSION);
                o.addProperty("rooms", rooms.size());
                o.addProperty("time", System.currentTimeMillis());
                return json(Response.Status.OK, o);
            }
            if (method == Method.GET && "/api/ping".equals(uri)) {
                JsonObject o = baseOk();
                o.addProperty("host", header(session, "host"));
                o.addProperty("version", VERSION);
                o.addProperty("time", System.currentTimeMillis());
                return json(Response.Status.OK, o);
            }
            if (method == Method.GET && "/api/access-test".equals(uri)) { JsonObject o=baseOk(); o.addProperty("version",VERSION); o.addProperty("mode","android-full"); o.addProperty("browser",header(session,"user-agent")); o.addProperty("time",System.currentTimeMillis()); return json(Response.Status.OK,o); }
            if (method == Method.GET && "/api/network".equals(uri)) return networkResponse();
            if (method == Method.GET && "/api/qr".equals(uri)) {
                String text = param(session, "text");
                if (text == null || text.trim().isEmpty()) return text(Response.Status.BAD_REQUEST, "Falta text", "text/plain; charset=utf-8");
                return text(Response.Status.OK, qrSvg(text.substring(0, Math.min(text.length(), 500))), "image/svg+xml; charset=utf-8");
            }
            if (method == Method.GET && "/api/state".equals(uri)) return apiState(session);
            if (method == Method.POST && "/api/create-room".equals(uri)) return apiCreateRoom(session);
            if (method == Method.POST && "/api/join-room".equals(uri)) return apiJoinRoom(session);
            if (method == Method.POST && "/api/action".equals(uri)) return apiAction(session);

            if (method == Method.GET && uri.matches("^/join/[A-Za-z0-9]{4,12}$")) {
                String code = uri.substring("/join/".length()).toUpperCase(Locale.ROOT);
                String host = header(session, "host");
                if (host == null || host.isEmpty()) host = preferredLanHost();
                Response r = redirect("http://" + host + "/?access=student&room=" + enc(code));
                r.addHeader("Set-Cookie", "rk_student=" + code + "; Path=/; SameSite=Lax; Max-Age=28800");
                return r;
            }
            if (method == Method.GET && "/abrir-profesor".equals(uri)) {
                if (studentRestricted(session)) return redirect("/?access=student&room=" + enc(restrictedRoom(session)));
                return redirect("http://127.0.0.1:" + listeningPort + "/?role=teacher");
            }
            if (method == Method.GET && "/diagnostico".equals(uri)) return diagnosticPage();
            if (method == Method.GET && ("/".equals(uri) || "/index.html".equals(uri))) {
                if (studentRestricted(session)) {
                    String role = param(session, "role");
                    String access = param(session, "access");
                    String room = param(session, "room");
                    if (room == null || room.isEmpty()) room = restrictedRoom(session);
                    if ((role != null && !role.isEmpty() && !allowedStudentRole(role)) || !"student".equals(access)) {
                        return redirect("/?access=student" + (room.isEmpty() ? "" : "&room=" + enc(room)));
                    }
                }
                return asset("public/index.html");
            }
            if (method == Method.GET && ("/instalar".equals(uri) || "/instalar/".equals(uri))) return asset("public/instalar.html");
            if (method == Method.GET) {
                String clean = uri.startsWith("/") ? uri.substring(1) : uri;
                if (clean.contains("..")) return text(Response.Status.FORBIDDEN, "No permitido", "text/plain");
                return asset("public/" + clean);
            }
            return text(Response.Status.NOT_FOUND, "No encontrado", "text/plain; charset=utf-8");
        } catch (Exception e) {
            JsonObject o = new JsonObject();
            o.addProperty("ok", false);
            o.addProperty("error", "Error interno: " + e.getMessage());
            return json(Response.Status.INTERNAL_ERROR, o);
        }
    }

    private Response apiState(IHTTPSession s) {
        Room room = roomOf(param(s, "room"));
        if (room == null) return error(Response.Status.NOT_FOUND, "Sala inexistente");
        String role = nz(param(s, "role"));
        if (studentRestricted(s) && !allowedStudentRole(role)) return error(Response.Status.FORBIDDEN, "Acceso QR restringido a Participante y Estación ACECode");
        try {
            JsonObject state = stateFor(room, role, nz(param(s, "clientId")), nz(param(s, "teamId")), nz(param(s, "hostKey")));
            saveRooms();
            JsonObject o = baseOk(); o.add("state", state); return json(Response.Status.OK, o);
        } catch (Exception e) { return error(Response.Status.FORBIDDEN, e.getMessage()); }
    }

    private Response apiCreateRoom(IHTTPSession s) {
        if (studentRestricted(s)) return error(Response.Status.FORBIDDEN, "Acceso QR restringido: no se puede crear una sala");
        Room room = newRoom();
        JsonObject o = baseOk();
        o.addProperty("roomCode", room.code); o.addProperty("hostKey", room.hostKey);
        try { o.add("state", stateFor(room, "teacher", "", "", room.hostKey)); } catch (Exception ignored) {}
        return json(Response.Status.OK, o);
    }

    private Response apiJoinRoom(IHTTPSession s) throws Exception {
        JsonObject p = bodyJson(s);
        Room room = roomOf(str(p, "roomCode"));
        if (room == null) return error(Response.Status.NOT_FOUND, "Sala inexistente");
        String role = str(p, "role");
        String clientId = str(p, "clientId");
        if (clientId.isEmpty()) clientId = token();
        if (studentRestricted(s) && !allowedStudentRole(role)) return error(Response.Status.FORBIDDEN, "Acceso QR restringido a Participante y Estación ACECode");
        String teamId = str(p, "teamId");
        if ("teacher".equals(role)) {
            if (!room.hostKey.equals(str(p, "hostKey"))) return error(Response.Status.FORBIDDEN, "Clave de profesor inválida");
        } else if ("player".equals(role)) {
            Participant user = room.participants.get(clientId);
            if (user == null) {
                String tid = validTeam(teamId) ? teamId : leastPopulatedTeam(room);
                String name = str(p, "name").trim();
                if (name.isEmpty()) name = "Participante";
                if (name.length() > 40) name = name.substring(0, 40);
                user = new Participant(clientId, name, tid);
                room.participants.put(clientId, user);
            } else user.lastSeen = now();
        } else if ("station".equals(role)) {
            String tid = validTeam(teamId) ? teamId : "azul";
            Station st = room.stations.get(tid);
            if (st == null) st = new Station(tid);
            st.lastSeen = now(); room.stations.put(tid, st);
            teamId = tid;
        } else if (!"screen".equals(role)) return error(Response.Status.BAD_REQUEST, "Rol inválido");
        saveRooms();
        try {
            JsonObject o = baseOk(); o.add("state", stateFor(room, role, clientId, teamId, str(p, "hostKey"))); return json(Response.Status.OK, o);
        } catch (Exception e) { return error(Response.Status.FORBIDDEN, e.getMessage()); }
    }

    private Response apiAction(IHTTPSession s) throws Exception {
        JsonObject p = bodyJson(s);
        Room room = roomOf(str(p, "roomCode"));
        if (room == null) return error(Response.Status.NOT_FOUND, "Sala inexistente");
        String role = str(p, "role"), type = str(p, "type"), clientId = str(p, "clientId");
        if (studentRestricted(s) && !allowedStudentRole(role)) return error(Response.Status.FORBIDDEN, "Acceso QR restringido a Participante y Estación ACECode");

        if ("player".equals(role)) {
            if (!"answer".equals(type)) return error(Response.Status.FORBIDDEN, "Acción no permitida");
            if (!"question".equals(room.phase) || room.revealed) return error(Response.Status.BAD_REQUEST, "La pregunta no está abierta");
            Participant user = room.participants.get(clientId);
            if (user == null) return error(Response.Status.FORBIDDEN, "Participante no registrado");
            Mission m = getMission(room);
            String value = str(p, "value");
            if (!validOption(m, value)) return error(Response.Status.BAD_REQUEST, "Respuesta inválida");
            room.responses.computeIfAbsent(String.valueOf(room.missionId), k -> new LinkedHashMap<>())
                    .computeIfAbsent(user.teamId, k -> new LinkedHashMap<>())
                    .put(clientId, new Answer(value));
            user.lastSeen = now(); saveRooms();
            JsonObject o = baseOk(); o.add("state", stateFor(room, "player", clientId, user.teamId, "")); return json(Response.Status.OK, o);
        }

        if ("station".equals(role)) {
            String teamId = str(p, "teamId"); if (!validTeam(teamId)) return error(Response.Status.BAD_REQUEST, "Equipo inválido");
            Station st = room.stations.get(teamId); if (st == null) st = new Station(teamId);
            if ("station-status".equals(type)) st.status = trim(str(p, "value"), 30);
            else if ("station-observation".equals(type)) st.observation = trim(str(p, "value"), 80);
            else return error(Response.Status.FORBIDDEN, "Acción no permitida");
            st.lastSeen = now(); room.stations.put(teamId, st); saveRooms(); return json(Response.Status.OK, baseOk());
        }

        if (!"teacher".equals(role) || !room.hostKey.equals(str(p, "hostKey"))) return error(Response.Status.FORBIDDEN, "Solo el profesor puede hacer esto");
        if ("set-phase".equals(type)) {
            String phase = str(p, "phase"); if (!PHASES.contains(phase)) return error(Response.Status.BAD_REQUEST, "Fase inválida");
            if ("question".equals(room.phase) && !"question".equals(phase) && !room.revealed) { room.revealed = true; scoreQuestion(room); }
            room.phase = phase;
        } else if ("set-mission".equals(type)) {
            int id = integer(p, "missionId", 1); room.missionId = Math.max(1, Math.min(missions.size(), id)); room.phase = "question"; room.revealed = false; room.timer = new TimerState();
        } else if ("reveal".equals(type)) {
            if (!room.revealed) { room.revealed = true; scoreQuestion(room); }
        } else if ("reset-question".equals(type)) {
            room.responses.put(String.valueOf(room.missionId), new LinkedHashMap<>()); room.revealed = false; room.digitalAwards.remove(String.valueOf(room.missionId)); recomputeScores(room);
        } else if ("set-turn-team".equals(type)) {
            String t = str(p, "teamId"); if (validTeam(t)) room.turnTeam = t;
        } else if ("toggle-evidence".equals(type)) {
            String id = str(p, "evidenceId"); if (!validEvidence(id)) return error(Response.Status.BAD_REQUEST, "Evidencia inválida");
            List<String> arr = room.evidenceOpen.computeIfAbsent(String.valueOf(room.missionId), k -> new ArrayList<>());
            boolean opened = p.has("opened") ? p.get("opened").getAsBoolean() : !arr.contains(id);
            if (opened && !arr.contains(id)) arr.add(id); if (!opened) arr.remove(id);
        } else if ("physical-pass".equals(type)) {
            String teamId = str(p, "teamId"); if (!validTeam(teamId)) return error(Response.Status.BAD_REQUEST, "Equipo inválido");
            room.physicalAwards.computeIfAbsent(String.valueOf(room.missionId), k -> new LinkedHashMap<>()).put(teamId, bool(p, "passed") ? 100 : 0); recomputeScores(room);
        } else if ("timer-start".equals(type)) {
            long rem = timerRemaining(room); if (rem <= 0) rem = room.timer.durationMs; room.timer.remainingMs = rem; room.timer.endAt = now() + rem; room.timer.running = true;
        } else if ("timer-pause".equals(type)) {
            room.timer.remainingMs = timerRemaining(room); room.timer.running = false; room.timer.endAt = 0;
        } else if ("timer-reset".equals(type)) {
            int sec = Math.max(10, Math.min(900, integer(p, "seconds", 60))); room.timer = new TimerState(sec * 1000L);
        } else return error(Response.Status.BAD_REQUEST, "Acción desconocida");
        room.updatedAt = now(); saveRooms(); return json(Response.Status.OK, baseOk());
    }

    private JsonObject stateFor(Room room, String role, String clientId, String teamId, String hostKey) throws Exception {
        Mission m = getMission(room); JsonObject common = commonState(room);
        if ("teacher".equals(role)) {
            if (!room.hostKey.equals(hostKey)) throw new Exception("Clave de profesor inválida");
            common.add("question", questionPublic(m, true));
            common.addProperty("teacher", m.teacher);
            common.add("program", gson.toJsonTree(m.program));
            common.add("responses", aggregateResponses(room));
            JsonArray ps = new JsonArray();
            for (Participant p : room.participants.values()) {
                JsonObject x = new JsonObject(); x.addProperty("id", p.clientId); x.addProperty("name", p.name); x.addProperty("teamId", p.teamId); x.addProperty("connected", connected(p.lastSeen)); x.addProperty("lastSeen", p.lastSeen); ps.add(x);
            }
            common.add("participants", ps);
            JsonArray evidence = evidenceCatalog(m, room); common.add("evidenceCatalog", evidence); common.addProperty("notes", room.notes == null ? "" : room.notes);
            return common;
        }
        if ("player".equals(role)) {
            Participant p = room.participants.get(clientId); if (p != null) p.lastSeen = now(); String tid = p != null ? p.teamId : teamId;
            common.add("question", questionPublic(m, room.revealed || "results".equals(room.phase)));
            if (p != null) { JsonObject me = new JsonObject(); me.addProperty("name", p.name); me.addProperty("teamId", p.teamId); me.addProperty("connected", true); common.add("me", me); } else common.add("me", null);
            String mine = null; Map<String, Map<String, Answer>> mr = room.responses.get(String.valueOf(room.missionId)); if (mr != null && mr.get(tid) != null && mr.get(tid).get(clientId) != null) mine = mr.get(tid).get(clientId).value;
            if (mine != null) common.addProperty("myAnswer", mine); else common.add("myAnswer", null);
            common.addProperty("canAnswer", "question".equals(room.phase) && !room.revealed);
            if (room.revealed) common.add("teamResults", aggregateResponses(room));
            common.add("evidence", openedEvidence(room, m));
            return common;
        }
        if ("station".equals(role)) {
            Station st = room.stations.get(teamId); if (st != null) st.lastSeen = now(); boolean allowed = Arrays.asList("programming", "testing", "results").contains(room.phase);
            if (allowed) { common.add("program", gson.toJsonTree(m.program)); common.addProperty("teacherPrompt", m.teacher); } else { common.add("program", null); common.add("teacherPrompt", null); }
            common.add("station", gson.toJsonTree(st != null ? st : new Station(teamId))); common.add("evidence", openedEvidence(room, m)); return common;
        }
        if ("screen".equals(role)) {
            common.add("question", questionPublic(m, room.revealed || "results".equals(room.phase))); if (room.revealed) common.add("teamResults", aggregateResponses(room)); common.add("evidence", openedEvidence(room, m)); return common;
        }
        return common;
    }

    private JsonObject commonState(Room room) {
        ensureTimer(room); Mission m = getMission(room); JsonObject o = new JsonObject();
        o.addProperty("roomCode", room.code); o.addProperty("missionId", room.missionId); o.addProperty("missionCount", missions.size()); o.addProperty("phase", room.phase); o.addProperty("revealed", room.revealed);
        JsonObject mi = new JsonObject(); mi.addProperty("id", m.id); mi.addProperty("title", m.title); mi.addProperty("stage", m.stage); mi.addProperty("subtitle", m.subtitle); o.add("mission", mi);
        JsonObject ti = new JsonObject(); ti.addProperty("running", room.timer.running); ti.addProperty("remainingMs", timerRemaining(room)); ti.addProperty("durationMs", room.timer.durationMs); o.add("timer", ti);
        o.addProperty("turnTeam", room.turnTeam); o.add("teams", teamSummary(room)); o.add("ranking", ranking(room)); o.addProperty("participantCount", room.participants.size()); o.add("phases", gson.toJsonTree(PHASES)); return o;
    }

    private JsonArray teamSummary(Room room) {
        JsonArray a = new JsonArray(); String mk = String.valueOf(room.missionId); Map<String, Map<String, Answer>> mr = room.responses.get(mk);
        for (Team t : TEAMS) {
            int connected = 0, total = 0; for (Participant p : room.participants.values()) if (t.id.equals(p.teamId)) { total++; if (connected(p.lastSeen)) connected++; }
            int answered = mr != null && mr.get(t.id) != null ? mr.get(t.id).size() : 0; JsonObject x = new JsonObject(); x.addProperty("id", t.id); x.addProperty("name", t.name); x.addProperty("emoji", t.emoji); x.addProperty("score", room.scores.getOrDefault(t.id, 0)); x.addProperty("connected", connected); x.addProperty("total", total); x.addProperty("answered", answered);
            Station st = room.stations.get(t.id); if (st != null) { JsonObject so = gson.toJsonTree(st).getAsJsonObject(); so.addProperty("connected", connected(st.lastSeen)); x.add("station", so); } else x.add("station", null); a.add(x);
        } return a;
    }

    private JsonArray ranking(Room room) {
        List<TeamScore> list = new ArrayList<>(); for (int i=0;i<TEAMS.length;i++) list.add(new TeamScore(TEAMS[i], room.scores.getOrDefault(TEAMS[i].id, 0), i));
        Collections.sort(list, Comparator.comparingInt((TeamScore x) -> -x.score).thenComparingInt(x -> x.order)); JsonArray a = new JsonArray();
        for (TeamScore s : list) { JsonObject x = new JsonObject(); x.addProperty("id", s.team.id); x.addProperty("name", s.team.name); x.addProperty("emoji", s.team.emoji); x.addProperty("score", s.score); a.add(x); } return a;
    }

    private JsonObject questionPublic(Mission m, boolean includeResolution) {
        JsonObject q = new JsonObject(); q.addProperty("title", m.question.title); q.addProperty("subtitle", m.question.subtitle); q.add("options", gson.toJsonTree(m.question.options));
        if (includeResolution) { q.addProperty("correct", m.question.correct); q.addProperty("explanation", m.question.explanation); } return q;
    }

    private JsonObject aggregateResponses(Room room) {
        Mission m = getMission(room); Map<String, Map<String, Answer>> mr = room.responses.get(String.valueOf(room.missionId)); JsonObject out = new JsonObject();
        for (Team t : TEAMS) {
            Map<String, Integer> counts = new LinkedHashMap<>(); int total = 0; if (mr != null && mr.get(t.id) != null) for (Answer a : mr.get(t.id).values()) { counts.put(a.value, counts.getOrDefault(a.value, 0) + 1); total++; }
            String majority = null; int best = -1; boolean tie = false; for (Map.Entry<String,Integer> e : counts.entrySet()) { if (e.getValue() > best) { best = e.getValue(); majority = e.getKey(); tie = false; } else if (e.getValue() == best) tie = true; } if (tie) majority = null;
            JsonObject x = new JsonObject(); x.add("counts", gson.toJsonTree(counts)); x.addProperty("total", total); if (majority != null) x.addProperty("majority", majority); else x.add("majority", null); if (room.revealed && majority != null) x.addProperty("correct", majority.equals(m.question.correct)); else x.add("correct", null); out.add(t.id, x);
        } return out;
    }

    private void scoreQuestion(Room room) {
        JsonObject agg = aggregateResponses(room); Mission m = getMission(room); Map<String,Integer> award = new LinkedHashMap<>();
        for (Team t : TEAMS) { JsonElement majority = agg.getAsJsonObject(t.id).get("majority"); award.put(t.id, majority != null && !majority.isJsonNull() && m.question.correct.equals(majority.getAsString()) ? 100 : 0); }
        room.digitalAwards.put(String.valueOf(room.missionId), award); recomputeScores(room);
    }

    private void recomputeScores(Room room) {
        Map<String,Integer> scores = new LinkedHashMap<>(); for (Team t:TEAMS) scores.put(t.id,0);
        for (Map<String,Integer> m : room.digitalAwards.values()) for (Team t:TEAMS) scores.put(t.id, scores.get(t.id)+m.getOrDefault(t.id,0));
        for (Map<String,Integer> m : room.physicalAwards.values()) for (Team t:TEAMS) scores.put(t.id, scores.get(t.id)+m.getOrDefault(t.id,0)); room.scores = scores;
    }

    private JsonArray evidenceCatalog(Mission m, Room room) {
        List<String> open = room.evidenceOpen.getOrDefault(String.valueOf(room.missionId), Collections.emptyList()); JsonArray a = new JsonArray();
        String[][] data = {{"pista","💡 Pista del profesor",m.teacher},{"observar","👀 Qué observar",m.program.observe},{"error","🧩 Error típico",m.program.error},{"pregunta","❓ Pregunta guía",m.program.question}};
        for (String[] d : data) { JsonObject o = new JsonObject(); o.addProperty("id",d[0]); o.addProperty("title",d[1]); o.addProperty("text",d[2]); o.addProperty("open",open.contains(d[0])); a.add(o); } return a;
    }

    private JsonArray openedEvidence(Room room, Mission m) {
        JsonArray all = evidenceCatalog(m, room), a = new JsonArray(); for (JsonElement e : all) if (e.getAsJsonObject().get("open").getAsBoolean()) { JsonObject c=e.getAsJsonObject().deepCopy(); c.remove("open"); a.add(c); } return a;
    }

    private Room newRoom() {
        String code; do { code = code(); } while (rooms.containsKey(code)); Room r = new Room(code, token()); rooms.put(code, r); saveRooms(); return r;
    }
    private Room roomOf(String code) { return code == null ? null : rooms.get(code.trim().toUpperCase(Locale.ROOT)); }
    private Mission getMission(Room room) { for (Mission m:missions) if (m.id==room.missionId) return m; return missions.get(0); }
    private long now() { return System.currentTimeMillis(); }
    private boolean connected(long ts) { return now()-ts < 15000; }
    private long timerRemaining(Room r) { return r.timer.running ? Math.max(0, r.timer.endAt-now()) : Math.max(0, r.timer.remainingMs); }
    private void ensureTimer(Room r) { long rem=timerRemaining(r); if (r.timer.running && rem<=0) { r.timer.running=false; r.timer.remainingMs=0; r.timer.endAt=0; } }
    private boolean validTeam(String id) { for (Team t:TEAMS) if (t.id.equals(id)) return true; return false; }
    private boolean validOption(Mission m,String v){for(List<String> o:m.question.options) if(!o.isEmpty()&&o.get(0).equals(v))return true;return false;}
    private boolean validEvidence(String id){return Arrays.asList("pista","observar","error","pregunta").contains(id);}
    private String leastPopulatedTeam(Room r) { String best=TEAMS[0].id; int n=Integer.MAX_VALUE; for(Team t:TEAMS){int c=0;for(Participant p:r.participants.values())if(t.id.equals(p.teamId))c++;if(c<n){n=c;best=t.id;}}return best; }

    private List<Mission> loadMissions() throws IOException {
        try (InputStream in = context.getAssets().open("missions.json")) { String json = new String(readAll(in), StandardCharsets.UTF_8); return gson.fromJson(json, new TypeToken<List<Mission>>(){}.getType()); }
    }
    private void loadRooms() {
        if (!dataFile.exists()) return; try (FileReader fr = new FileReader(dataFile)) { List<Room> list = gson.fromJson(fr, new TypeToken<List<Room>>(){}.getType()); if(list!=null)for(Room r:list){r.normalize();ensureTimer(r);recomputeScores(r);rooms.put(r.code,r);} } catch(Exception ignored){}
    }
    private synchronized void saveRooms() { try (FileWriter fw = new FileWriter(dataFile)) { gson.toJson(new ArrayList<>(rooms.values()), fw); } catch(Exception ignored){} }

    private Response networkResponse() {
        JsonObject o=baseOk(); JsonArray a=new JsonArray(); List<NetInfo> nets=networkList(); for(NetInfo n:nets){JsonObject x=new JsonObject();x.addProperty("name",n.name);x.addProperty("address",n.address);x.addProperty("url",n.url);x.addProperty("score",n.score);a.add(x);} o.addProperty("port",listeningPort);o.add("interfaces",a); if(!nets.isEmpty()){NetInfo n=nets.get(0);JsonObject p=new JsonObject();p.addProperty("name",n.name);p.addProperty("address",n.address);p.addProperty("url",n.url);p.addProperty("score",n.score);o.add("preferred",p);}else o.add("preferred",null);o.addProperty("local","http://127.0.0.1:"+listeningPort);o.addProperty("publicUrl","");o.addProperty("internetReady",false);return json(Response.Status.OK,o);
    }
    private List<NetInfo> networkList() {
        List<NetInfo> out=new ArrayList<>(); try { Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces(); while(en.hasMoreElements()){NetworkInterface ni=en.nextElement();if(!ni.isUp()||ni.isLoopback())continue;Enumeration<java.net.InetAddress> as=ni.getInetAddresses();while(as.hasMoreElements()){java.net.InetAddress ia=as.nextElement();String ip=ia.getHostAddress();if(ip==null||ip.contains(":" )||ia.isLoopbackAddress())continue;int score=privateIp(ip)?100:0;String name=ni.getName();if(name.matches("(?i).*(wlan|wifi|eth).*"))score+=30;if(name.matches("(?i).*(tun|vpn|docker|vbox|vmnet).*"))score-=100;out.add(new NetInfo(name,ip,"http://"+ip+":"+listeningPort,score));}}}catch(Exception ignored){} out.sort((a,b)->Integer.compare(b.score,a.score)); return out;
    }
    private boolean privateIp(String s){return s.startsWith("10.")||s.startsWith("192.168.")||s.matches("172\\.(1[6-9]|2[0-9]|3[01])\\..*");}
    private String preferredLanHost(){List<NetInfo> n=networkList();return n.isEmpty()?"127.0.0.1:"+listeningPort:n.get(0).address+":"+listeningPort;}

    private Response diagnosticPage(){StringBuilder li=new StringBuilder();for(NetInfo n:networkList())li.append("<li><b>").append(n.name).append("</b>: <a href=\"").append(n.url).append("/api/ping\">").append(n.url).append("/api/ping</a></li>");String html="<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>RoboKids diagnóstico</title><style>body{font-family:Arial;max-width:760px;margin:30px auto;padding:20px;color:#10224d}.ok{background:#e8f8ef;padding:14px;border-radius:12px}</style><h1>RoboKids LAB V20 Android FULL</h1><div class=ok>Servidor activo en puerto <b>"+listeningPort+"</b>.</div><p>Desde otro dispositivo abrí:</p><ul>"+li+"</ul>";return text(Response.Status.OK,html,"text/html; charset=utf-8");}

    private boolean studentRestricted(IHTTPSession s){return !restrictedRoom(s).isEmpty();}
    private String restrictedRoom(IHTTPSession s){String raw=header(s,"cookie");if(raw==null)return"";for(String part:raw.split(";")){String p=part.trim();if(p.startsWith("rk_student="))return p.substring("rk_student=".length()).toUpperCase(Locale.ROOT);}return"";}
    private boolean allowedStudentRole(String r){return "player".equals(r)||"station".equals(r);}

    private Response asset(String path) {
        try(InputStream in=context.getAssets().open(path)){byte[] data=readAll(in);return newFixedLengthResponse(Response.Status.OK,mime(path),new java.io.ByteArrayInputStream(data),data.length);}catch(Exception e){return text(Response.Status.NOT_FOUND,"No encontrado","text/plain; charset=utf-8");}
    }
    private String mime(String p){String s=p.toLowerCase(Locale.ROOT);if(s.endsWith(".html"))return"text/html; charset=utf-8";if(s.endsWith(".js"))return"application/javascript; charset=utf-8";if(s.endsWith(".css"))return"text/css; charset=utf-8";if(s.endsWith(".json")||s.endsWith(".webmanifest"))return"application/json; charset=utf-8";if(s.endsWith(".png"))return"image/png";if(s.endsWith(".svg"))return"image/svg+xml";return"application/octet-stream";}
    private byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);return b.toByteArray();}

    private Response json(Response.Status st,JsonObject o){return newFixedLengthResponse(st,"application/json; charset=utf-8",gson.toJson(o));}
    private Response error(Response.Status st,String msg){JsonObject o=new JsonObject();o.addProperty("ok",false);o.addProperty("error",msg);return json(st,o);}
    private JsonObject baseOk(){JsonObject o=new JsonObject();o.addProperty("ok",true);return o;}
    private Response text(Response.Status st,String body,String mime){return newFixedLengthResponse(st,mime,body);}
    private Response redirect(String url){Response r=newFixedLengthResponse(Response.Status.REDIRECT,"text/plain; charset=utf-8","");r.addHeader("Location",url);r.addHeader("Cache-Control","no-store");return r;}
    private String header(IHTTPSession s,String k){String v=s.getHeaders().get(k.toLowerCase(Locale.ROOT));return v==null?"":v;}
    private String param(IHTTPSession s,String k){return s.getParms().get(k);}
    private JsonObject bodyJson(IHTTPSession s)throws Exception{Map<String,String> files=new HashMap<>();s.parseBody(files);String body=files.get("postData");if(body==null||body.isEmpty())return new JsonObject();return gson.fromJson(body,JsonObject.class);}
    private String str(JsonObject o,String k){return o!=null&&o.has(k)&&!o.get(k).isJsonNull()?o.get(k).getAsString():"";}
    private int integer(JsonObject o,String k,int def){try{return o.has(k)?o.get(k).getAsInt():def;}catch(Exception e){return def;}}
    private boolean bool(JsonObject o,String k){try{return o.has(k)&&o.get(k).getAsBoolean();}catch(Exception e){return false;}}
    private String nz(String s){return s==null?"":s;}
    private String trim(String s,int n){return s==null?"":s.substring(0,Math.min(s.length(),n));}
    private String enc(String s){try{return URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}
    private String code(){String chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";StringBuilder b=new StringBuilder();for(int i=0;i<6;i++)b.append(chars.charAt(random.nextInt(chars.length())));return b.toString();}
    private String token(){byte[] b=new byte[18];random.nextBytes(b);StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.ROOT,"%02x",x));return s.toString();}
    private String qrSvg(String txt)throws WriterException{Map<EncodeHintType,Object> hints=new HashMap<>();hints.put(EncodeHintType.ERROR_CORRECTION,ErrorCorrectionLevel.M);hints.put(EncodeHintType.MARGIN,2);BitMatrix m=new QRCodeWriter().encode(txt,BarcodeFormat.QR_CODE,0,0,hints);int n=m.getWidth(),scale=8,size=n*scale;StringBuilder s=new StringBuilder("<svg xmlns='http://www.w3.org/2000/svg' width='").append(size).append("' height='").append(size).append("' viewBox='0 0 ").append(n).append(" ").append(n).append("'><rect width='100%' height='100%' fill='white'/><path d='");for(int y=0;y<n;y++)for(int x=0;x<n;x++)if(m.get(x,y))s.append("M").append(x).append(" ").append(y).append("h1v1h-1z");return s.append("' fill='black'/></svg>").toString();}

    static class Team { String id,name,emoji; Team(String i,String n,String e){id=i;name=n;emoji=e;} }
    static class TeamScore { Team team; int score,order; TeamScore(Team t,int s,int o){team=t;score=s;order=o;} }
    static class NetInfo { String name,address,url; int score; NetInfo(String n,String a,String u,int s){name=n;address=a;url=u;score=s;} }
    static class Participant { String clientId,name,teamId; long joinedAt,lastSeen; Participant(String c,String n,String t){clientId=c;name=n;teamId=t;joinedAt=lastSeen=System.currentTimeMillis();} }
    static class Station { String teamId,status="esperando",observation=""; long lastSeen=System.currentTimeMillis(); Station(String t){teamId=t==null||t.isEmpty()?"azul":t;} }
    static class Answer { String value; long at; Answer(String v){value=v;at=System.currentTimeMillis();} }
    static class TimerState { boolean running=false; long durationMs=60000,remainingMs=60000,endAt=0; TimerState(){} TimerState(long ms){durationMs=remainingMs=ms;} }
    static class Room {
        String code,hostKey,phase="question",turnTeam="azul",notes=""; long createdAt=System.currentTimeMillis(),updatedAt=createdAt; int missionId=1; boolean revealed=false;
        Map<String,Participant> participants=new LinkedHashMap<>(); Map<String,Station> stations=new LinkedHashMap<>(); Map<String,Map<String,Map<String,Answer>>> responses=new LinkedHashMap<>();
        Map<String,Map<String,Integer>> digitalAwards=new LinkedHashMap<>(),physicalAwards=new LinkedHashMap<>(); Map<String,Integer> scores=new LinkedHashMap<>(); Map<String,List<String>> evidenceOpen=new LinkedHashMap<>(); TimerState timer=new TimerState();
        Room(String c,String h){code=c;hostKey=h;for(Team t:TEAMS)scores.put(t.id,0);} void normalize(){if(participants==null)participants=new LinkedHashMap<>();if(stations==null)stations=new LinkedHashMap<>();if(responses==null)responses=new LinkedHashMap<>();if(digitalAwards==null)digitalAwards=new LinkedHashMap<>();if(physicalAwards==null)physicalAwards=new LinkedHashMap<>();if(scores==null)scores=new LinkedHashMap<>();if(evidenceOpen==null)evidenceOpen=new LinkedHashMap<>();if(timer==null)timer=new TimerState();if(phase==null)phase="question";if(turnTeam==null)turnTeam="azul";}
    }
    static class Mission { int id; String title,stage,subtitle,teacher; Question question; Program program; }
    static class Question { String title,subtitle,correct,explanation; List<List<String>> options; }
    static class Program { List<String> concepts,blocks,steps; List<List<String>> params; String observe,error,question,success,imageKey,imageTitle,imageNote; }
}
