# RoboKids LAB V20 Android FULL

Aplicación Android FULL basada en RoboKids LAB Nivel 1 V20 con las imágenes corregidas.

El dispositivo Android inicia un servidor local integrado y permite usar **Profesor**, **Proyector/TV**, **Participante** y **Estación ACECode** desde la misma app. Otros dispositivos de la misma red Wi‑Fi pueden ingresar mediante el QR de la sala.

## Compatibilidad
- Android 7.0 o superior.
- Chrome/WebView actualizado recomendado.
- Puertos locales 3000 a 3010.

## Importante sobre Internet / datos móviles
El APK incluye el servidor FULL local. Para que terceros ingresen desde otra red o desde datos móviles a un Android que actúa como anfitrión se requiere una URL pública/túnel o backend cloud, porque las redes móviles suelen usar CGNAT y no permiten conexiones entrantes directas.

Artefacto de compilación: `RoboKids_LAB_V20_Android_FULL.apk`.
