@echo off
setlocal
cd /d "%~dp0"
echo ===========================================
echo  RoboKids LAB V20 - Android FULL APK
echo ===========================================
echo.
echo Requiere Android SDK y Gradle configurados.
gradle :app:assembleDebug
if errorlevel 1 (
  echo.
  echo [ERROR] No se pudo compilar.
  pause
  exit /b 1
)
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "RoboKids_LAB_V20_Android_FULL.apk" >nul
echo.
echo [OK] RoboKids_LAB_V20_Android_FULL.apk
pause
