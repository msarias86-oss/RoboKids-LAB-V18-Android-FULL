@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RoboKids LAB V23 - INTERNET
color 1F
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\iniciar_internet_v23.ps1"
exit /b %errorlevel%
