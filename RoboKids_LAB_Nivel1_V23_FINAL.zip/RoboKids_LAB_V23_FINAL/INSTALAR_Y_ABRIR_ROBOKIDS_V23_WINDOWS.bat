@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RoboKids LAB V23 - Instalar y abrir
color 1F

echo ======================================================
echo   ROBOKIDS LAB V23 - INSTALAR ICONO Y ABRIR
echo ======================================================
echo.
echo Se creara un acceso directo RoboKids LAB en el Escritorio.
echo Luego podras abrir la app con un solo doble click.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\crear_acceso_directo.ps1"
if errorlevel 1 (
  echo.
  echo [AVISO] No se pudo crear el acceso directo.
  echo La aplicacion igualmente se abrira ahora.
  echo Luego podras usar ABRIR_ROBOKIDS_LAB_V23.bat
  echo.
) else (
  echo.
  echo [OK] Acceso directo instalado en el Escritorio.
)

echo [OK] Abriendo RoboKids LAB V23 con acceso por Internet...
echo.
call "%~dp0ABRIR_ROBOKIDS_LAB_V23.bat"
exit /b %errorlevel%
