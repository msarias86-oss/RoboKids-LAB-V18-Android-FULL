@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0INICIAR_ROBOKIDS_V22_WINDOWS.bat"
exit /b %errorlevel%
